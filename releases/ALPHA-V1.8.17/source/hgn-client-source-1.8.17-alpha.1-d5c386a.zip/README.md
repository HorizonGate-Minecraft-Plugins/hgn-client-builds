<div align="center">

<img src=".github/assets/hgn-wordmark-v2.svg" alt="HorizonGate Network" width="520" />

**The official launcher of the HorizonGate Network.**

Sign in with Microsoft for your Minecraft profile, install a supported game
version, and join the network in one click — with the matching HGN client fetched
and verified by the launcher when an immutable build is available.

<img src=".github/assets/hgn-github-banner-v2.png" alt="Illustrated HorizonGate Network portal and floating islands" width="100%" />

*Illustrative HorizonGate Network artwork; see the verified captures below for product UI.*

</div>

---

## What it does

The `1.8.17-alpha.1` / `ALPHA-V1.8.17` PC source candidate reserves a distinct
identity for the next build. It has no matching immutable client artifact set or
verified installer/game release yet. The earlier `1.8.16-alpha.1` candidate adds a
default-off HGN hotbar preview and improves compact settings and refreshed
Cosmetics selection. Packaged Fabric UI/resource and Sodium handoff checks passed
on representative versions; all 35 loader targets, in-world visuals, and live
backend/proxy acceptance still need verification before a public release.

The `1.8.15-alpha.1` client candidate adds live FPS, ping and left/right CPS
readouts, localized current biome names, the actual client build version, and
cyan hotbar/boss-bar framing while preserving Minecraft's native survival,
offhand and vehicle indicators. Readout text and panels follow the Compact,
Standard and Large HUD size setting.
The reference-driven HUD and in-game HGN Client overhaul remain in progress.
The seven HGN Client concepts below do **not** specify a launcher redesign;
the desktop launcher's pre-October-10 appearance has been restored in source
and checked in a development window, while its real account, installation and
mod-version functions remain. No installer has been verified from this source.
The existing guarded play flow remains authoritative. The public
ALPHA-V1.8.15 installer predates the new experimental hotbar.
The library now separates loading, retryable errors and a genuinely empty library,
retaining previously loaded installations if a refresh fails.
Settings has a compact HGN heading and build/platform footer while retaining all
existing settings sections and upstream attribution.
The skin page uses a bounded live preview and HGN sign-in card, retaining explicit
Apply/Reset actions and the existing Microsoft authentication flow.
Profile & Skins is available in the primary navigation. The titlebar no longer
claims the network is online without a server check.
The `1.8.15-alpha.1` container pass includes icon-based creative categories, a
separate search lane, live survival player preview, vertical grindstone inputs,
smithing role labels and separate storage illustration panels. Native inventory
capacities and interactions remain authoritative. Cartography retains its native
live map preview and operations beneath the HGN panel skin.

The HGN MC Launcher is a full Minecraft launcher. It handles Microsoft sign-in,
downloads Java and the game, and keeps your installations up to date. Official
and supported custom installations carry the **HGN client** — a layer that
restyles the game menu, pins the official servers, and talks to the network's
plugins. Automatic injection through every modpack-install path is still
deferred and must not be assumed by pack authors or testers.

- **One-click network access** — VinkSMP and the Hub sit on the home screen with
  their own artwork. Press play and the game starts *and connects*; there is no
  server address to type. They cannot be lost by accident: delete the
  installation and it is rebuilt the next time you play.
- **Matched Minecraft versions** — the source declares a future 35-target
  Minecraft 1.21 through 1.21.11 Fabric/Forge/NeoForge matrix (no Forge
  1.21.2). The `1.8.17-alpha.1` candidate does not yet have that immutable
  published set. Selectors and native create/edit/import/launch paths enforce
  the package policy; official servers can require a particular game version.
- **The HGN client is launcher-managed** — where a matching published build is
  available, the launcher downloads, verifies, installs, and updates it; you do
  not need to drop a jar into a folder yourself.
- **Mods, resource packs and custom installations** — the full content browser is
  there when you want it. Choosing Vanilla in the supported custom-setup flow
  still gives you the HGN client, since a client layer needs a loader underneath
  to run. Imported modpacks remain a separate, deferred integration path.
- **Readable at compact sizes** — the dashboard and Cosmetics Store adapt their
  cards and text to smaller Minecraft windows without covering controls. The
  ordinary feature area contains Settings and Cosmetics; staff-only tools are
  not advertised to players.
- **Accurate launch status** — home remembers the selected installation and
  shows its own runtime, memory and folder. Loading, incomplete installs, running
  games and retryable failures have distinct controls; unknown state never says ready.
- **Account handoff** — verified launches can preload a UUID-bound cosmetics
  snapshot before the client opens. Connection and cached/offline states are shown
  separately; purchases and equipment changes still require backend authorization.

<div align="center">

<img src=".github/assets/server-vinksmp.png" alt="VinkSMP" width="110" />
&nbsp;&nbsp;&nbsp;
<img src=".github/assets/server-hub-v2.png" alt="Illustrated HorizonGate Network Hub gateway" width="110" />

</div>

The Hub thumbnail is illustrative artwork, not an in-game capture.

## PC client screens: development and packaged QA

### Latest native development view (not a packaged-release capture)

The `1.8.17-alpha.1` client at source commit `0fd645c` opened in an isolated
Fabric 1.21.4 development run on October 12. These are actual game-window
captures at a 1672 x 941 client area with GUI scale 2. The run used an
unlinked local test profile: its example player is not an authenticated HGN
account, and no server join, wallet, purchased cosmetic, or installer was
tested. The current layout is still simpler than the seven owner concepts.

| Menu | Settings | Installed Mods (empty test installation) |
| :---: | :---: | :---: |
| <img src=".github/assets/screens/client-menu-1.8.17-dev-20261012.png" alt="Unreleased HGN Client menu in an isolated Fabric development run" /> | <img src=".github/assets/screens/client-settings-1.8.17-dev-20261012.png" alt="Unreleased HGN Client settings in an isolated Fabric development run" /> | <img src=".github/assets/screens/client-mods-1.8.17-dev-20261012.png" alt="Unreleased HGN Client empty Mods page in an isolated Fabric development run" /> |

The same source produced a remapped Fabric 1.21.4 JAR, but these screenshots
came from a development run, **not** from installing or running that packaged
JAR. Keep the packaged gallery below separate until the current exact build
passes account, backend, and owner visual acceptance.

### Current packaged Fabric 1.21.4 QA (unreleased)

The five non-Cosmetics window captures below were refreshed on October 13 from
the packaged candidate JAR rebuilt at source commit `51158fd`, SHA-256
`7C076EF2CC0634A4E7309880CBAC0FD09AF5C74C740531D3E02A736802892B1D`.
The Cosmetics capture was refreshed after the sidebar-width fix from the
rebuilt JAR with SHA-256
`572A0CE672492ACA960EB28921EA39B9B56DE9253A6AC0ABDD846E996A7647F8`.
All six are 1672 × 941 game-window pixels. The guarded packaged Fabric 1.21.4
production-client harness logged `HGN_VISUAL_READY` for each routed page;
the earlier five-page run exited cleanly. Quick Status reads the game's measured FPS; the 30 FPS shown
on the menu is from this Mesa software-rendered run, not a promised rate.
The game ran at GUI scale 2 in an isolated profile with Mesa software OpenGL.
The `Player` names were unlinked test identities; no paid-account session or wallet was
supplied. Server ping and availability shown below are capture-time observations,
not evidence of a successful join.

| Main menu | Settings |
| :---: | :---: |
| <img src=".github/assets/screens/client-menu-1.8.17-current-packaged-qa-20261013.png" alt="October 13 exact-current packaged HGN Client main menu at 1672 by 941 game pixels, showing measured Mesa FPS on an unlinked test profile" /> | <img src=".github/assets/screens/client-settings-1.8.17-current-packaged-qa-20261013.png" alt="October 13 exact-current packaged HGN Client settings at GUI scale 2" /> |
| Installed Mods (empty) | Cosmetics (unlinked) |
| <img src=".github/assets/screens/client-mods-1.8.17-current-packaged-qa-20261013.png" alt="October 13 exact-current packaged HGN Client showing an illustrated discovery panel and no installed mod JARs" /> | <img src=".github/assets/screens/client-cosmetics-1.8.17-current-packaged-qa-20261013.png" alt="October 13 exact-current packaged HGN Client cosmetics with no verified catalogue or balance" /> |
| Official servers (capture-time ping) | Saved servers |
| <img src=".github/assets/screens/client-servers-1.8.17-current-packaged-qa-20261013.png" alt="October 13 exact-current packaged HGN Client official server list with capture-time ping" /> | <img src=".github/assets/screens/client-saved-servers-1.8.17-current-packaged-qa-20261013.png" alt="October 13 exact-current packaged HGN Client saved server list" /> |

This is packaged **source QA**, not proof of paid sign-in, live catalogue or
credits, a managed loader-free client, the 35-target matrix, an installer smoke,
or a public release. These screens remain substantially simpler than the
owner's seven design references below. Audio could not be tested on this host.
The test-only routing hook opened these pages without mouse navigation. The
October 13 run did not verify installed-mod interaction, screen click targets,
paid-account state, or a real multiplayer join on the current JAR.

### Launcher-managed client prototype QA (unreleased)

The 1.21.4 client also started from the non-shipping HGN runtime agent. The
current runtime pair was built from source commit `bd36433`, agent SHA-256
`395A71DAA2068379B44877BC14CC8C0862F6B390359BA43352C7760188B40E8B`.
Its runtime-pair proof SHA-256 was
`C235E52F52577E500650208A5EDE1A4F9A00EF01179FB56976A7D27875637D4F`.
In a fresh production Fabric run, the loader listed Minecraft, Java, Fabric
Loader, and three pinned Fabric API modules, **without an HGN Fabric mod**.
The log then recorded HGN client initialization, loaded the separate HGN
resource ZIP, rendered the Menu, Cosmetics, and Mods pages, and exited cleanly.
These are 1672 × 941 game-window captures from that exact agent run:

| Managed Menu | Managed Cosmetics | Managed Mods |
| :---: | :---: | :---: |
| <img src=".github/assets/screens/client-managed-menu-1.8.17-qa-20261013.png" alt="Unreleased launcher-managed HGN client menu with no HGN Fabric mod registration" /> | <img src=".github/assets/screens/client-managed-cosmetics-1.8.17-qa-20261013.png" alt="Unlinked HGN cosmetics screen from the managed runtime agent" /> | <img src=".github/assets/screens/client-managed-mods-1.8.17-qa-20261013.png" alt="Managed HGN Mods screen with no installed player mod JARs" /> |

This proves local agent startup and screen rendering, not a packaged HGN
Launcher installation, paid sign-in, live backend credits, real server join,
 Sodium interaction, or a release. Fabric Loader remains the underlying
Minecraft loader; HGN itself is injected by the launcher-managed agent rather
than registered as a Fabric mod. The run used an unlinked test identity and
Mesa software rendering; the host had no working audio device.

An additional October 13 production-game smoke loaded the pinned
[Sodium 0.6.13 Fabric 1.21.4 release](https://modrinth.com/mod/sodium/version/mc1.21.4-0.6.13-fabric)
beside those three Fabric API modules, still with no HGN mod registration.
The HGN agent initialized, the resource ZIP loaded, the Menu and Settings
screens reached their ready markers, and the game exited cleanly. A second
Sodium run clicked the actual Video settings button from HGN Settings and
rendered the native HGN Video Settings page before another clean exit:

<img src=".github/assets/screens/client-managed-sodium-video-1.8.17-qa-20261013.png" alt="Unreleased managed HGN client Video Settings after clicking from HGN Settings with Sodium loaded" width="800" />

This checks the local button-to-screen path on Mesa software rendering. One
native control displayed "Setting unavailable" on that host; hardware FPS,
option changes, multiplayer, and packaged launcher startup are still open.

### Earlier 1.21.4 source-candidate visual smoke

These are actual packaged Fabric 1.21.4 game-window captures from the
`1.8.17-alpha.1` source candidate at commit
`da449f205ac7a2f90ba3368193c989bf7c6586bf`. The remapped JAR
(SHA-256 `AE8A41CA656ED185961180518825B64AB21A009624617B0E11C69A6C336BB880`)
passed its payload/resource audit and opened at 1280 × 720, GUI scale 2, on an
offline, unlinked `Player946` test profile. The Dashboard, Settings and
Cosmetics screens rendered without visibly corrupt HGN textures or glyphs.

<img src=".github/assets/screens/client-dashboard-1.8.17-source-qa.png" alt="Unreleased packaged Fabric 1.21.4 HGN Dashboard on an offline test profile" width="100%" />

| Settings | Cosmetics — unlinked |
| :---: | :---: |
| <img src=".github/assets/screens/client-settings-1.8.17-source-qa.png" alt="Unreleased packaged Fabric 1.21.4 HGN Settings at GUI scale 2" /> | <img src=".github/assets/screens/client-cosmetics-1.8.17-source-qa.png" alt="Unreleased packaged Fabric 1.21.4 HGN Cosmetics with no linked account or verified items" /> |

These are source QA captures, **not** proof of paid sign-in, live catalogue or
wallet, a managed loader-free client, all 35 target builds, a Windows installer,
or a public release. The current screens are still substantially simpler than
the owner's design references below.

<details>
<summary>Earlier packaged Minecraft 1.21.11 captures (1.8.15 source candidate)</summary>

These actual captures come from a packaged **Minecraft 1.21.11 Fabric**
`1.8.15-alpha.1` candidate JAR built from source commit `289d4a4`. The visual
test used an unlinked profile and a disposable world. Its installed-mod list is
empty, and Cosmetics shows no verified catalogue or wallet. The server screen
shows Minecraft ping information observed during capture; it does not verify
current server status, player counts, or a deployed membership backend.

| Menu | Worlds |
| :---: | :---: |
| <img src=".github/assets/screens/client-menu-1.21.11.png" alt="Packaged HGN Client menu at 1280 by 720" /> | <img src=".github/assets/screens/client-worlds-1.21.11.png" alt="Packaged HGN Client worlds at 1500 by 840 with disposable test world" /> |
| Official servers (capture-time ping) | Installed mods (empty test profile) |
| <img src=".github/assets/screens/client-servers-1.21.11.png" alt="Packaged HGN Client official server browser" /> | <img src=".github/assets/screens/client-mods-1.21.11.png" alt="Packaged HGN Client installed-mod browser with no additional mods" /> |
| Cosmetics — unlinked | Settings |
| <img src=".github/assets/screens/client-cosmetics-1.21.11.png" alt="Packaged HGN Client Cosmetics showing an unlinked account state" /> | <img src=".github/assets/screens/client-settings-1.21.11.png" alt="Packaged HGN Client HUD settings at 1500 by 840" /> |

The same JAR was captured at a physical **640 × 480** window (Minecraft's
minimum logical GUI height at scale 2):

| Compact menu | Compact Cosmetics |
| :---: | :---: |
| <img src=".github/assets/screens/client-compact-menu-1.21.11.png" alt="Packaged HGN Client menu at 640 by 480" /> | <img src=".github/assets/screens/client-compact-cosmetics-1.21.11.png" alt="Packaged HGN Client Cosmetics at 640 by 480" /> |
| Compact settings | Compact saved servers |
| <img src=".github/assets/screens/client-compact-settings-1.21.11.png" alt="Packaged HGN Client settings at 640 by 480" /> | <img src=".github/assets/screens/client-compact-saved-servers-1.21.11.png" alt="Packaged HGN Client saved servers at 640 by 480" /> |

These captures verify rendered layouts and resource loading, not an authenticated
purchase/equip flow, a completed PC release, or a phone edition. The separate
membership backend and Velocity plugin still require a live rollout and test.

</details>

<details>
<summary>Owner-supplied HGN Client design references (concepts, not product captures)</summary>

These seven images show the intended visual direction for the PC client. They
are reference mockups, **not** screenshots of a built release. Example FPS,
latency, player counts, friends, cosmetics, currencies, mods and worlds in them
must not be presented as live data or implemented features without verification.

| Home | Singleplayer |
| :---: | :---: |
| <img src=".github/assets/screens/references/client-concept-home.png" alt="Owner concept for the HGN Client home menu" width="480" /> | <img src=".github/assets/screens/references/client-concept-worlds.png" alt="Owner concept for the HGN Client singleplayer library" width="480" /> |
| Official network | Multiplayer browser |
| <img src=".github/assets/screens/references/client-concept-network.png" alt="Owner concept for the official HorizonGate Network page" width="480" /> | <img src=".github/assets/screens/references/client-concept-multiplayer.png" alt="Owner concept for the multiplayer server browser" width="480" /> |
| Mods | Settings |
| <img src=".github/assets/screens/references/client-concept-mods.png" alt="Owner concept for in-client mod management" width="480" /> | <img src=".github/assets/screens/references/client-concept-settings.png" alt="Owner concept for compact client settings" width="480" /> |
| Cosmetics | |
| <img src=".github/assets/screens/references/client-concept-cosmetics.png" alt="Owner concept for the cosmetics collection" width="480" /> | |

</details>

### Current PC launcher QA (unreleased)

The `1.8.17-alpha.1` Windows launcher was built from the current PC candidate
source on October 16 and opened with a disposable, signed-out profile. These
captures show the actual native EXE, not the seven in-game HGN Client concepts.

| Home | Mod release list |
| :---: | :---: |
| <img src=".github/assets/screens/launcher-home-1.8.17-native-qa-20261016.png" alt="Unreleased 1.8.17 native HGN Launcher home with an isolated signed-out profile" /> | <img src=".github/assets/screens/launcher-mod-versions-1.8.17-native-qa-20261016.png" alt="Unreleased 1.8.17 native HGN Launcher showing Fabric API versions and per-release details" /> |

This is visual/navigation QA only. The unsigned installer has not passed an
isolated install/uninstall test, paid Java sign-in, HGN credits, managed-client
launch, multiplayer join, or God's Eye acceptance; it is not a public release.

<details>
<summary>Earlier launcher and connection captures</summary>

| Launcher home | Launch progress |
| :---: | :---: |
| <img src=".github/assets/screens/launcher-home.png" alt="Earlier HGN Launcher home capture" /> | <img src=".github/assets/screens/loading-screen.png" alt="Earlier HGN Launcher progress capture" /> |
| Earlier main menu | Earlier multiplayer |
| <img src=".github/assets/screens/main-menu.png" alt="Earlier HGN main menu" /> | <img src=".github/assets/screens/multiplayer.png" alt="Earlier HGN multiplayer screen" /> |
| Joining the Hub | Joining VinkSMP |
| <img src=".github/assets/screens/join-hub.png" alt="Earlier Hub connection capture" /> | <img src=".github/assets/screens/join-vinksmp.png" alt="Earlier VinkSMP connection capture" /> |

</details>

## Download

Get a Windows installer from
[public Releases](https://github.com/HorizonGate-Minecraft-Plugins/hgn-client-builds/releases).
Check its release notes and assets for the client version you intend to run. The
earlier packaged Minecraft 1.21.11 gallery documents the `1.8.15-alpha.1`
test client at source commit `289d4a4`. The unreleased 1.8.17 source QA images
and the seven concept references do not establish current installer
availability. Enable the Alpha update channel in launcher settings, sign in
with your Microsoft account, and press play.
Alpha and Beta remain opt-in update channels.

### Uninstall on Windows 11

Close HGN Launcher and Minecraft, then open **Settings → Apps → Installed apps**,
find **HGN Launcher**, and choose **Uninstall**. The released
`HGN-Launcher-Setup.exe` registers this entry; a copied
`HGN Launcher Remake Preview.exe` is portable and does not. To remove a portable
preview, close it and delete only that preview EXE. Published older client builds
use a launcher-managed Minecraft mod; the unreleased 1.21.4 candidate uses a
launcher-managed runtime agent instead. Neither is a separate Windows app. A normal
launcher uninstall keeps game data unless you explicitly choose to delete app
data; back up worlds before removing installations or choosing data deletion.

## Planned Minecraft version matrix

The source lists **Minecraft 1.21 through 1.21.11**: Fabric and NeoForge on all
twelve versions, plus Forge on eleven versions because Forge 1.21.2 is
unavailable. That is a target matrix, not proof that 35 current-source jars have
been built or published. A release may offer only the exact assets in its
immutable manifest; the launcher checks each downloaded jar against that
release's size and SHA-256 identity. Minecraft 26.x remains unsupported;
metadata placeholders are not published client builds.

## Repository layout

| Path | Contents |
| --- | --- |
| `apps/app` | Launcher shell (Tauri, Rust) |
| `apps/app-frontend` | Launcher interface (Vue 3) |
| `packages/app-lib` | Game installation, launching and authentication |
| `client/` | The HGN Minecraft client — see [client/README.md](client/README.md) |

Client builds are published separately to
[hgn-client-builds](https://github.com/HorizonGate-Minecraft-Plugins/hgn-client-builds).

## Building

Requires Node 22, pnpm 10, Rust (stable) and JDK 21.

```bash
cp packages/app-lib/.env.prod packages/app-lib/.env   # compile-time config
pnpm install
pnpm --filter @modrinth/app run build                 # produces the installer
```

The installer lands in `target/release/bundle/`.
Check the [public releases](https://github.com/HorizonGate-Minecraft-Plugins/hgn-client-builds/releases)
for the current Windows installer and its exact release notes. A source branch or
manual workflow artifact is not a published update. Each published client release
must have its own immutable 35-build manifest and verified Windows installer;
older release identities are never overwritten. The owner UI examples guide
future work and are not by themselves evidence that a release implements them.

> The frontend is embedded into the binary at Rust compile time, so a
> frontend-only change needs `touch apps/app/src/main.rs` to be picked up.

For the client itself, see [client/README.md](client/README.md).

## Links

- [HorizonGate Network](https://horizongate.online)
- [Discord](https://discord.gg/ctj5TAbUsX)

## Licence and attribution

Licensed under **GPL-3.0**. See [COPYING.md](COPYING.md).

This launcher is a fork of the [Modrinth App](https://github.com/modrinth/code),
also GPL-3.0. Modrinth's branding has been removed as that licence requires, but
the copyright of the original authors remains theirs, and the upstream project
deserves the credit for the launcher foundations this is built on.

The HorizonGate Network name, logos and artwork are not covered by that licence
and remain the property of the HorizonGate Network.
