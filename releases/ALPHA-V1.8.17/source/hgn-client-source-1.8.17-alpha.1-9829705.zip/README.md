<div align="center">

<img src=".github/assets/hgn-wordmark-v2.svg" alt="HorizonGate Network" width="520" />

**The official launcher of the HorizonGate Network.**

Sign in with Microsoft for your Minecraft profile, install the supported game
version, and join the network in one click — with the HGN client already built in.

<img src=".github/assets/hgn-github-banner-v2.png" alt="Illustrated HorizonGate Network portal and floating islands" width="100%" />

*Illustrative HorizonGate Network artwork; see the verified captures below for product UI.*

</div>

---

## What it does

The `1.8.17-alpha.1` / `ALPHA-V1.8.17` PC source candidate reserves a distinct
identity for the next build. It has no matching immutable client artifact set or
verified installer/game release yet. The earlier `1.8.16-alpha.1` candidate adds a
default-off HGN hotbar preview and improves compact settings and refreshed
Cosmetics selection. Packaged Fabric UI/resource and Sodium handoff checks passed
on representative versions; all 35 loader targets, in-world visuals, and live
backend/proxy acceptance still need verification before a public release.

The `1.8.15-alpha.1` client candidate adds live FPS, ping and left/right CPS
readouts, localized current biome names, the actual client build version, and
cyan hotbar/boss-bar framing while preserving Minecraft's native survival,
offhand and vehicle indicators. Readout text and panels follow the Compact,
Standard and Large HUD size setting.
The reference-driven HUD overhaul and launcher remake remain in progress.
Launcher Home now has a compact welcome panel and real selectable installation
cards; the existing guarded play flow remains authoritative. The public
ALPHA-V1.8.15 installer predates the new experimental hotbar.
The library now separates loading, retryable errors and a genuinely empty library,
retaining previously loaded installations if a refresh fails.
Settings has a compact HGN heading and build/platform footer while retaining all
existing settings sections and upstream attribution.
The skin page uses a bounded live preview and HGN sign-in card, retaining explicit
Apply/Reset actions and the existing Microsoft authentication flow.
Profile & Skins is available in the primary navigation. The titlebar no longer
claims the network is online without a server check.
The `1.8.15-alpha.1` container pass includes icon-based creative categories, a
separate search lane, live survival player preview, vertical grindstone inputs,
smithing role labels and separate storage illustration panels. Native inventory
capacities and interactions remain authoritative. Cartography retains its native
live map preview and operations beneath the HGN panel skin.

The HGN MC Launcher is a full Minecraft launcher. It handles Microsoft sign-in,
downloads Java and the game, and keeps your installations up to date. Official
and supported custom installations carry the **HGN client** — a layer that
restyles the game menu, pins the official servers, and talks to the network's
plugins. Automatic injection through every modpack-install path is still
deferred and must not be assumed by pack authors or testers.

- **One-click network access** — VinkSMP and the Hub sit on the home screen with
  their own artwork. Press play and the game starts *and connects*; there is no
  server address to type. They cannot be lost by accident: delete the
  installation and it is rebuilt the next time you play.
- **Matched Minecraft versions** — this Alpha's client matrix covers Minecraft
  1.21 through 1.21.11 on Fabric, Forge, and NeoForge (35 targets; no Forge
  1.21.2). Selectors and native create/edit/import/launch paths enforce the same
  package policy; official servers can require a particular game version.
- **The HGN client comes with it** — installed and updated by the launcher, not
  something you download and drop into a folder.
- **Mods, resource packs and custom installations** — the full content browser is
  there when you want it. Choosing Vanilla in the supported custom-setup flow
  still gives you the HGN client, since a client layer needs a loader underneath
  to run. Imported modpacks remain a separate, deferred integration path.
- **Readable at compact sizes** — the dashboard and Cosmetics Store adapt their
  cards and text to smaller Minecraft windows without covering controls. The
  ordinary feature area contains Settings and Cosmetics; staff-only tools are
  not advertised to players.
- **Accurate launch status** — home remembers the selected installation and
  shows its own runtime, memory and folder. Loading, incomplete installs, running
  games and retryable failures have distinct controls; unknown state never says ready.
- **Account handoff** — verified launches can preload a UUID-bound cosmetics
  snapshot before the client opens. Connection and cached/offline states are shown
  separately; purchases and equipment changes still require backend authorization.

<div align="center">

<img src=".github/assets/server-vinksmp.png" alt="VinkSMP" width="110" />
&nbsp;&nbsp;&nbsp;
<img src=".github/assets/server-hub-v2.png" alt="Illustrated HorizonGate Network Hub gateway" width="110" />

</div>

The Hub thumbnail is illustrative artwork, not an in-game capture.

## Packaged PC client screens

These actual captures come from a packaged **Minecraft 1.21.11 Fabric**
`1.8.15-alpha.1` candidate JAR built from source commit `289d4a4`. The visual
test used an unlinked profile and a disposable world. Its installed-mod list is
empty, and Cosmetics shows no verified catalogue or wallet. The server screen
shows Minecraft ping information observed during capture; it does not verify
current server status, player counts, or a deployed membership backend.

| Menu | Worlds |
| :---: | :---: |
| <img src=".github/assets/screens/client-menu-1.21.11.png" alt="Packaged HGN Client menu at 1280 by 720" /> | <img src=".github/assets/screens/client-worlds-1.21.11.png" alt="Packaged HGN Client worlds at 1500 by 840 with disposable test world" /> |
| Official servers (capture-time ping) | Installed mods (empty test profile) |
| <img src=".github/assets/screens/client-servers-1.21.11.png" alt="Packaged HGN Client official server browser" /> | <img src=".github/assets/screens/client-mods-1.21.11.png" alt="Packaged HGN Client installed-mod browser with no additional mods" /> |
| Cosmetics — unlinked | Settings |
| <img src=".github/assets/screens/client-cosmetics-1.21.11.png" alt="Packaged HGN Client Cosmetics showing an unlinked account state" /> | <img src=".github/assets/screens/client-settings-1.21.11.png" alt="Packaged HGN Client HUD settings at 1500 by 840" /> |

The same JAR was captured at a physical **640 × 480** window (Minecraft's
minimum logical GUI height at scale 2):

| Compact menu | Compact Cosmetics |
| :---: | :---: |
| <img src=".github/assets/screens/client-compact-menu-1.21.11.png" alt="Packaged HGN Client menu at 640 by 480" /> | <img src=".github/assets/screens/client-compact-cosmetics-1.21.11.png" alt="Packaged HGN Client Cosmetics at 640 by 480" /> |
| Compact settings | Compact saved servers |
| <img src=".github/assets/screens/client-compact-settings-1.21.11.png" alt="Packaged HGN Client settings at 640 by 480" /> | <img src=".github/assets/screens/client-compact-saved-servers-1.21.11.png" alt="Packaged HGN Client saved servers at 640 by 480" /> |

These captures verify rendered layouts and resource loading, not an authenticated
purchase/equip flow, a completed PC release, or a phone edition. The separate
membership backend and Velocity plugin still require a live rollout and test.

<details>
<summary>Owner-supplied HGN Client design references (concepts, not product captures)</summary>

These seven images show the intended visual direction for the PC client. They
are reference mockups, **not** screenshots of a built release. Example FPS,
latency, player counts, friends, cosmetics, currencies, mods and worlds in them
must not be presented as live data or implemented features without verification.

| Home | Singleplayer |
| :---: | :---: |
| <img src=".github/assets/screens/references/client-concept-home.png" alt="Owner concept for the HGN Client home menu" width="480" /> | <img src=".github/assets/screens/references/client-concept-worlds.png" alt="Owner concept for the HGN Client singleplayer library" width="480" /> |
| Official network | Multiplayer browser |
| <img src=".github/assets/screens/references/client-concept-network.png" alt="Owner concept for the official HorizonGate Network page" width="480" /> | <img src=".github/assets/screens/references/client-concept-multiplayer.png" alt="Owner concept for the multiplayer server browser" width="480" /> |
| Mods | Settings |
| <img src=".github/assets/screens/references/client-concept-mods.png" alt="Owner concept for in-client mod management" width="480" /> | <img src=".github/assets/screens/references/client-concept-settings.png" alt="Owner concept for compact client settings" width="480" /> |
| Cosmetics | |
| <img src=".github/assets/screens/references/client-concept-cosmetics.png" alt="Owner concept for the cosmetics collection" width="480" /> | |

</details>

<details>
<summary>Earlier launcher and connection captures</summary>

| Launcher home | Launch progress |
| :---: | :---: |
| <img src=".github/assets/screens/launcher-home.png" alt="Earlier HGN Launcher home capture" /> | <img src=".github/assets/screens/loading-screen.png" alt="Earlier HGN Launcher progress capture" /> |
| Earlier main menu | Earlier multiplayer |
| <img src=".github/assets/screens/main-menu.png" alt="Earlier HGN main menu" /> | <img src=".github/assets/screens/multiplayer.png" alt="Earlier HGN multiplayer screen" /> |
| Joining the Hub | Joining VinkSMP |
| <img src=".github/assets/screens/join-hub.png" alt="Earlier Hub connection capture" /> | <img src=".github/assets/screens/join-vinksmp.png" alt="Earlier VinkSMP connection capture" /> |

</details>

## Download

Get a Windows installer from
[public Releases](https://github.com/HorizonGate-Minecraft-Plugins/hgn-client-builds/releases).
Check its release notes and assets for the client version you intend to run. The
screenshots above document the packaged `1.8.15-alpha.1` test candidate at
source commit `289d4a4`; they do not establish installer availability. Enable
the Alpha update channel in launcher settings, sign in with your Microsoft
account, and press play.
Alpha and Beta remain opt-in update channels.

### Uninstall on Windows 11

Close HGN Launcher and Minecraft, then open **Settings → Apps → Installed apps**,
find **HGN Launcher**, and choose **Uninstall**. The released
`HGN-Launcher-Setup.exe` registers this entry; a copied
`HGN Launcher Remake Preview.exe` is portable and does not. To remove a portable
preview, close it and delete only that preview EXE. The HGN Client is a Minecraft
mod inside launcher-managed installations, not a separate Windows app. A normal
launcher uninstall keeps game data unless you explicitly choose to delete app
data; back up worlds before removing installations or choosing data deletion.

## Supported Minecraft versions

The HGN Client supports the exact **Minecraft 1.21 through 1.21.11** matrix:
Fabric and NeoForge on all twelve versions, plus Forge on eleven versions because
Forge 1.21.2 is unavailable. All 35 client jars are downloaded on demand and
verified against their release-scoped size and SHA-256 identity. Minecraft 26.x
remains unsupported; metadata placeholders are not published client builds.

## Repository layout

| Path | Contents |
| --- | --- |
| `apps/app` | Launcher shell (Tauri, Rust) |
| `apps/app-frontend` | Launcher interface (Vue 3) |
| `packages/app-lib` | Game installation, launching and authentication |
| `client/` | The HGN Minecraft client — see [client/README.md](client/README.md) |

Client builds are published separately to
[hgn-client-builds](https://github.com/HorizonGate-Minecraft-Plugins/hgn-client-builds).

## Building

Requires Node 22, pnpm 10, Rust (stable) and JDK 21.

```bash
cp packages/app-lib/.env.prod packages/app-lib/.env   # compile-time config
pnpm install
pnpm --filter @modrinth/app run build                 # produces the installer
```

The installer lands in `target/release/bundle/`.
Check the [public releases](https://github.com/HorizonGate-Minecraft-Plugins/hgn-client-builds/releases)
for the current Windows installer and its exact release notes. A source branch or
manual workflow artifact is not a published update. Each published client release
must have its own immutable 35-build manifest and verified Windows installer;
older release identities are never overwritten. The owner UI examples guide
future work and are not by themselves evidence that a release implements them.

> The frontend is embedded into the binary at Rust compile time, so a
> frontend-only change needs `touch apps/app/src/main.rs` to be picked up.

For the client itself, see [client/README.md](client/README.md).

## Links

- [HorizonGate Network](https://horizongate.online)
- [Discord](https://discord.gg/ctj5TAbUsX)

## Licence and attribution

Licensed under **GPL-3.0**. See [COPYING.md](COPYING.md).

This launcher is a fork of the [Modrinth App](https://github.com/modrinth/code),
also GPL-3.0. Modrinth's branding has been removed as that licence requires, but
the copyright of the original authors remains theirs, and the upstream project
deserves the credit for the launcher foundations this is built on.

The HorizonGate Network name, logos and artwork are not covered by that licence
and remain the property of the HorizonGate Network.
