package online.horizongate.hgn.forge;

import io.netty.buffer.Unpooled;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.EventNetworkChannel;
import net.minecraftforge.network.PacketDistributor;
import online.horizongate.hgn.HgnClient;
import online.horizongate.hgn.HgnPlatform;
import online.horizongate.hgn.compat.HgnCompat;
import online.horizongate.hgn.net.HgnMessages;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.function.Consumer;

/**
 * Forge entrypoint. Forge has no vanilla-payload registrar, so the HGN channels
 * are raw {@link EventNetworkChannel}s carrying the same UTF-8 JSON bytes the
 * Fabric and NeoForge builds exchange.
 *
 * <p>Nothing here touches a Forge event bus: start-up and join are driven from
 * vanilla mixins instead, which keeps this one file valid across the EventBus 5
 * to EventBus 7 change in 1.21.6.
 */
@Mod("hgn-client")
public final class HgnForge implements HgnPlatform {
	private static EventNetworkChannel coreChannel;

	public HgnForge() {
		HgnPlatform.install(this);
		HgnClient.init();

		coreChannel = channel("core", HgnMessages::handleCore);
		channel("vinksmp", HgnMessages::handleVink);
	}

	private static EventNetworkChannel channel(String path, Consumer<String> handler) {
		EventNetworkChannel ch = ChannelBuilder.named(HgnCompat.id("hgn", path)).optional().eventNetworkChannel();
		ch.addListener((CustomPayloadEvent event) -> {
			FriendlyByteBuf payload = event.getPayload();
			if (payload == null) {
				return;
			}
			byte[] bytes = new byte[payload.readableBytes()];
			payload.readBytes(bytes);
			String json = new String(bytes, StandardCharsets.UTF_8);
			event.getSource().enqueueWork(() -> handler.accept(json));
			event.getSource().setPacketHandled(true);
		});
		return ch;
	}

	@Override
	public Path configDir() {
		return FMLPaths.CONFIGDIR.get();
	}

	@Override
	public boolean canSendCore() {
		return Minecraft.getInstance().getConnection() != null;
	}

	@Override
	public void sendCore(String json) {
		try {
			FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
			buf.writeBytes(json.getBytes(StandardCharsets.UTF_8));
			coreChannel.send(buf, PacketDistributor.SERVER.with(null));
		} catch (Exception e) {
			HgnClient.LOGGER.debug("[hgn:core] server does not accept the channel", e);
		}
	}

	@Override
	public String loaderName() {
		return "forge";
	}
}
