import java.awt.Font;
import java.nio.file.Files;
import java.nio.file.Path;

/** Confirms the bundled UI font itself contains the Latin glyphs used by client headings. */
public final class HgnBundledFontTest {
	public static void main(String[] args) throws Exception {
		if (args.length != 1) throw new AssertionError("Expected the HGN UI font path");
		Path path = Path.of(args[0]);
		try (var input = Files.newInputStream(path)) {
			Font font = Font.createFont(Font.TRUETYPE_FONT, input);
			String sample = "HGN012a";
			int missing = font.canDisplayUpTo(sample);
			if (missing != -1) {
				throw new AssertionError("HGN UI font lacks Latin glyph " + sample.charAt(missing));
			}
		}
		System.out.println("HGN UI TrueType font contains representative Latin glyphs.");
	}
}
