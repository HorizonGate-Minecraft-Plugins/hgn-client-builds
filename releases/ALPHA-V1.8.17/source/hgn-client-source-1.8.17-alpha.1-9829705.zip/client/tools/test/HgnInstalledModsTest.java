import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import online.horizongate.hgn.screen.HgnInstalledModsIndex;
import online.horizongate.hgn.ui.HgnInstalledModsLayout;
import online.horizongate.hgn.ui.HgnRect;

/** Pure-JDK checks for honest installed-jar discovery and compact menu geometry. */
public final class HgnInstalledModsTest {
	public static void main(String[] args) throws Exception {
		checkLayout();
		checkIndex();
		System.out.println("HgnInstalledModsTest passed");
	}

	private static void checkLayout() {
		for (int[] size : new int[][]{{320, 180}, {550, 350}, {836, 471},
			{1280, 720}, {1920, 1080}}) {
			HgnInstalledModsLayout layout = HgnInstalledModsLayout.resolve(size[0], size[1]);
			HgnRect screen = new HgnRect(0, 0, size[0], size[1]);
			inside(screen, layout.panel());
			for (HgnRect control : new HgnRect[]{layout.search(), layout.list(),
				layout.detail(), layout.back(), layout.refresh(), layout.manage(),
				layout.previous(), layout.next()}) inside(layout.panel(), control);
			check(layout.search().bottom() < layout.list().y(), "Search overlaps list");
			check(layout.list().bottom() < layout.detail().y(), "List overlaps details");
			check(layout.detail().bottom() < layout.back().y(), "Details overlap footer");
			check(layout.back().right() < layout.refresh().x(), "Back overlaps refresh");
			check(layout.refresh().right() < layout.manage().x(), "Refresh overlaps launcher");
			check(layout.manage().right() < layout.previous().x(), "Launcher overlaps pager");
			check(layout.previous().right() < layout.next().x(), "Pager controls overlap");
			check(layout.rowsPerPage() >= 4, "Installed jars need several visible rows");
			for (int row = 0; row < layout.rowsPerPage(); row++) {
				inside(layout.list(), layout.row(row));
				if (row > 0) check(layout.row(row - 1).bottom() < layout.row(row).y(),
					"Installed jar rows overlap");
			}
			check(layout.pages(0) == 1, "Empty view needs one page");
			check(layout.pages(layout.rowsPerPage() + 1) == 2, "Paging dropped a jar");
		}
		check(HgnInstalledModsLayout.resolve(320, 180).compact(), "320x180 needs compact mode");
		check(!HgnInstalledModsLayout.resolve(550, 350).compact(), "550x350 should be roomy");
	}

	private static void checkIndex() throws Exception {
		Path instance = Files.createTempDirectory("hgn-installed-mods-test-");
		Path mods = instance.resolve("mods");
		Path sodium = mods.resolve("sodium-fabric-0.6.13+mc1.21.4.jar");
		Path iris = mods.resolve("Iris-1.8.5+mc1.21.4.JAR");
		Path disabled = mods.resolve("disabled.jar.disabled");
		Path readme = mods.resolve("readme.txt");
		Path nested = mods.resolve("nested");
		Path nestedJar = nested.resolve("not-in-root.jar");
		try {
			HgnInstalledModsIndex.Snapshot missing = HgnInstalledModsIndex.read(instance);
			check(missing.jars().isEmpty() && !missing.problem().isEmpty(),
				"Missing folder must be honest and empty");
			Files.createDirectories(nested);
			Files.writeString(sodium, "sodium bytes");
			Files.writeString(iris, "iris bytes");
			Files.writeString(disabled, "disabled bytes");
			Files.writeString(readme, "not a jar");
			Files.writeString(nestedJar, "nested bytes");
			HgnInstalledModsIndex.Snapshot found = HgnInstalledModsIndex.read(instance);
			check(found.problem().isEmpty(), "Readable folder reported an error");
			check(found.jars().stream().map(HgnInstalledModsIndex.InstalledJar::fileName)
				.toList().equals(List.of("Iris-1.8.5+mc1.21.4.JAR",
					"sodium-fabric-0.6.13+mc1.21.4.jar")),
				"Only exact root JAR filenames should appear, in sorted order");
			check(found.filter("MC1.21.4").size() == 2, "Search should be case insensitive");
			check(found.filter("sodium").getFirst().fileName().equals(sodium.getFileName().toString()),
				"Search must retain the exact installed filename and version text");
			check(found.filter("missing").isEmpty(), "Search invented a result");
			check(Files.readString(sodium).equals("sodium bytes"), "Index changed installed file");
			boolean immutable = false;
			try {
				found.jars().clear();
			} catch (UnsupportedOperationException expected) {
				immutable = true;
			}
			check(immutable, "Snapshot must not expose mutable jar data");
		} finally {
			Files.deleteIfExists(nestedJar);
			Files.deleteIfExists(nested);
			Files.deleteIfExists(sodium);
			Files.deleteIfExists(iris);
			Files.deleteIfExists(disabled);
			Files.deleteIfExists(readme);
			Files.deleteIfExists(mods);
			Files.deleteIfExists(instance);
		}
	}

	private static void inside(HgnRect outer, HgnRect inner) {
		check(inner.width() > 0 && inner.height() > 0 && inner.x() >= outer.x()
			&& inner.y() >= outer.y() && inner.right() <= outer.right()
			&& inner.bottom() <= outer.bottom(), "Control escaped its panel: " + inner);
	}

	private static void check(boolean condition, String message) {
		if (!condition) throw new AssertionError(message);
	}
}
