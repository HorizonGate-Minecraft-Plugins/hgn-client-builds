import online.horizongate.hgn.ui.HgnDashboardLayout;
import online.horizongate.hgn.ui.HgnRect;
import online.horizongate.hgn.ui.HgnReferenceShellLayout;

/** Guards the reference-style header, eight destinations and featured action. */
public final class HgnReferenceShellLayoutTest {
	public static void main(String[] args) {
		int cases = 0;
		for (int[] viewport : new int[][] {{640, 360}, {836, 471}, {1100, 704},
			{1280, 720}, {1672, 941}}) {
			int width = viewport[0];
			int height = viewport[1];
			HgnReferenceShellLayout shell = new HgnReferenceShellLayout(
				HgnDashboardLayout.resolve(width, height));
			HgnRect rail = shell.rail();
			HgnRect hero = shell.featuredNetwork();
			within(rail, width, height);
			within(hero, width, height);
			within(shell.wordmark(), width, height);
			within(shell.versionBadge(), width, height);
			if (rail.right() >= hero.x() || shell.wordmark().bottom() >= rail.y()
				|| shell.versionBadge().bottom() >= hero.y()) {
				throw new AssertionError("Header, rail and hero overlap");
			}
			HgnRect action = shell.featuredAction();
			within(action, width, height);
			if (action.x() < hero.x() || action.right() > hero.right()
				|| action.y() < hero.y() || action.bottom() > hero.bottom()) {
				throw new AssertionError("Featured action left its hero");
			}
			for (int index = 0; index < HgnReferenceShellLayout.DESTINATIONS; index++) {
				HgnRect destination = shell.destination(index);
				within(destination, width, height);
				if (destination.width() < 100 || destination.height() < 20
					|| destination.x() < rail.x() || destination.right() > rail.right()
					|| destination.y() < rail.y() || destination.bottom() > rail.bottom()) {
					throw new AssertionError("Navigation target is cramped or outside the rail");
				}
				if (index > 0 && shell.destination(index - 1).bottom() >= destination.y()) {
					throw new AssertionError("Navigation targets overlap");
				}
			}
			cases++;
		}
		System.out.println("Reference shell: " + cases + " wide viewports keep all eight actions usable.");
	}

	private static void within(HgnRect rect, int width, int height) {
		if (rect.x() < 0 || rect.y() < 0 || rect.right() > width || rect.bottom() > height) {
			throw new AssertionError("Reference shell element is outside the viewport: " + rect);
		}
	}
}
