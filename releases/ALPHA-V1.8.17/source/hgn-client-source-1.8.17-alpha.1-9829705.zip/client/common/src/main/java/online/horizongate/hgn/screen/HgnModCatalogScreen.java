package online.horizongate.hgn.screen;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import online.horizongate.hgn.HgnClient;
import online.horizongate.hgn.HgnPlatform;
import online.horizongate.hgn.compat.HgnCompat;
import online.horizongate.hgn.compat.HgnScaledEditBox;
import online.horizongate.hgn.ui.HgnIcon;
import online.horizongate.hgn.ui.HgnModCatalogLayout;
import online.horizongate.hgn.ui.HgnPalette;
import online.horizongate.hgn.ui.HgnRect;
import online.horizongate.hgn.ui.HgnScreenBackdrop;
import online.horizongate.hgn.ui.HgnSurface;
import online.horizongate.hgn.ui.dashboard.HgnTypography;
import online.horizongate.hgn.ui.widget.HgnButton;

/** Read-only Modrinth browser for the Minecraft version and loader of this client. */
public final class HgnModCatalogScreen extends Screen {
	private static final int SEARCH_BATCH_SIZE = 20;
	private final Screen parent;
	private final HgnModCatalog catalog = new HgnModCatalog();
	private final String gameVersion = HgnClient.minecraftVersion();
	private final String loader = HgnPlatform.get().loaderName().toLowerCase(Locale.ROOT);
	private HgnModCatalogLayout layout;
	private EditBox searchBox;
	private String searchText = "";
	private List<HgnModCatalog.Project> projects = List.of();
	private List<HgnModCatalog.Release> releases = List.of();
	private HgnModCatalog.Project selectedProject;
	private HgnModCatalog.Release selectedRelease;
	private int totalHits;
	private int projectOffset;
	private int projectPage;
	private int releasePage;
	private int searchTicket;
	private int releaseTicket;
	private int searchDelay;
	private boolean initialized;
	private boolean searchLoading;
	private boolean releaseLoading;
	private String searchError = "";
	private String releaseError = "";

	public HgnModCatalogScreen(Screen parent) {
		super(Component.literal("HGN Mod Catalogue"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		rebuild();
		if (!initialized) {
			initialized = true;
			search(0);
		}
	}

	@Override
	public void tick() {
		if (searchDelay > 0 && --searchDelay == 0) search(0);
	}

	private void rebuild() {
		boolean focusSearch = searchBox != null && searchBox.isFocused();
		clearWidgets();
		layout = HgnModCatalogLayout.resolve(width, height);
		projectPage = Math.min(projectPage,
			Math.max(0, (projects.size() - 1) / layout.projectRowsPerPage()));
		releasePage = Math.min(releasePage,
			Math.max(0, (releases.size() - 1) / layout.releaseRowsPerPage()));
		HgnRect searchBounds = layout.search();
		searchBox = addRenderableWidget(new HgnScaledEditBox(font, searchBounds.x(),
			searchBounds.y(), searchBounds.width(), searchBounds.height(),
			Component.literal("Search compatible Modrinth mods"),
			layout.compact() ? 0.82f : 0.95f));
		searchBox.setMaxLength(80);
		searchBox.setBordered(false);
		searchBox.setHint(HgnCompat.uiText(layout.compact() ? "Search mods..."
			: "Search Modrinth mods for this Minecraft version..."));
		searchBox.setValue(searchText);
		searchBox.setResponder(value -> {
			if (value.equals(searchText)) return;
			searchText = value;
			searchDelay = 12;
		});
		if (focusSearch) searchBox.setFocused(true);
		button(layout.searchAction(), "SEARCH", () -> search(0));
		if (!layout.compact() || selectedProject == null) addProjectControls();
		if (!layout.compact() || selectedProject != null) addReleaseControls();
		button(layout.back(), layout.compact() && selectedProject != null
			? "RESULTS" : layout.compact() ? "BACK" : "BACK TO INSTALLED", () -> {
			if (layout.compact() && selectedProject != null) {
				selectedProject = null;
				selectedRelease = null;
				releaseTicket++;
				rebuild();
			} else onClose();
		});
		button(layout.openLauncher(), layout.compact() ? "LAUNCHER" : "OPEN LAUNCHER",
			() -> HgnCompat.openUrl(HgnModsLauncherLink.fromEnvironment()));
		String reviewLink = selectionLink();
		String reviewLabel = selectedRelease == null ? "SELECT A RELEASE"
			: reviewLink == null ? layout.compact() ? "START IN LAUNCHER"
				: "START FROM LAUNCHER TO REVIEW" : "REVIEW IN LAUNCHER";
		HgnButton review = button(layout.review(), reviewLabel, this::reviewSelection);
		review.active = reviewLink != null && !releaseLoading;
	}

	private void addProjectControls() {
		List<HgnModCatalog.Project> visible = visibleProjects();
		for (int row = 0; row < visible.size(); row++) {
			HgnModCatalog.Project project = visible.get(row);
			HgnRect bounds = layout.projectRow(row);
			addRenderableWidget(HgnButton.hitTarget(bounds.x(), bounds.y(),
				bounds.width(), bounds.height(), Component.literal("Show versions for " + project.title()),
				ignored -> selectProject(project)));
		}
		HgnButton previous = button(layout.projectPrevious(), "<", () -> {
			if (projectPage > 0) {
				projectPage--;
				rebuild();
			} else search(Math.max(0, projectOffset - SEARCH_BATCH_SIZE), true);
		});
		previous.active = !searchLoading && (projectPage > 0 || projectOffset > 0);
		HgnButton next = button(layout.projectNext(), ">", () -> {
			if ((projectPage + 1) * layout.projectRowsPerPage() < projects.size()) {
				projectPage++;
				rebuild();
			} else search(projectOffset + SEARCH_BATCH_SIZE);
		});
		next.active = !searchLoading && ((projectPage + 1) * layout.projectRowsPerPage()
			< projects.size() || projectOffset + SEARCH_BATCH_SIZE < totalHits
				&& projectOffset + SEARCH_BATCH_SIZE <= 5_000);
	}

	private void addReleaseControls() {
		int first = releasePage * layout.releaseRowsPerPage();
		int last = Math.min(releases.size(), first + layout.releaseRowsPerPage());
		for (int index = first; index < last; index++) {
			HgnModCatalog.Release release = releases.get(index);
			HgnRect bounds = layout.releaseRow(index - first);
			addRenderableWidget(HgnButton.hitTarget(bounds.x(), bounds.y(),
				bounds.width(), bounds.height(), Component.literal("Select " + release.label()),
				ignored -> {
					selectedRelease = release;
					rebuild();
				}));
		}
		if (selectedProject != null && !releaseError.isEmpty()) {
			button(layout.releaseRow(0), "RETRY RELEASES", () -> selectProject(selectedProject));
		}
		HgnButton previous = button(layout.releasePrevious(), "<", () -> {
			releasePage--;
			rebuild();
		});
		previous.active = releasePage > 0;
		HgnButton next = button(layout.releaseNext(), ">", () -> {
			releasePage++;
			rebuild();
		});
		next.active = (releasePage + 1) * layout.releaseRowsPerPage() < releases.size();
	}

	private HgnButton button(HgnRect bounds, String label, Runnable action) {
		return addRenderableWidget(HgnButton.dashboardCentered(bounds.x(), bounds.y(),
			bounds.width(), bounds.height(), Component.literal(label), false,
			ignored -> action.run()).referenceScale(1.0f));
	}

	private void search(int offset) {
		search(offset, false);
	}

	private void search(int offset, boolean lastPage) {
		searchDelay = 0;
		projectOffset = offset;
		projectPage = 0;
		searchLoading = true;
		searchError = "";
		projects = List.of();
		totalHits = 0;
		selectedProject = null;
		selectedRelease = null;
		releases = List.of();
		releaseLoading = false;
		releaseError = "";
		releasePage = 0;
		releaseTicket++;
		int ticket = ++searchTicket;
		String query = searchText;
		Minecraft client = minecraft;
		rebuild();
		CompletableFuture.supplyAsync(() -> {
			try {
				return new SearchOutcome(catalog.search(query, gameVersion, loader, offset), "");
			} catch (InterruptedException error) {
				Thread.currentThread().interrupt();
				return new SearchOutcome(null, "Catalogue request interrupted. Try again.");
			} catch (IOException error) {
				return new SearchOutcome(null, failureMessage(error));
			} catch (RuntimeException error) {
				return new SearchOutcome(null, "Catalogue search failed. Try again.");
			}
		}).thenAccept(outcome -> client.execute(() -> {
			if (client.screen != this || ticket != searchTicket) return;
			searchLoading = false;
			searchError = outcome.error();
			if (outcome.result() != null) {
				projects = outcome.result().projects();
				totalHits = outcome.result().totalHits();
				if (lastPage) projectPage = Math.max(0,
					(projects.size() - 1) / layout.projectRowsPerPage());
			}
			rebuild();
		}));
	}

	private void selectProject(HgnModCatalog.Project project) {
		selectedProject = project;
		selectedRelease = null;
		releases = List.of();
		releasePage = 0;
		releaseError = "";
		releaseLoading = true;
		int ticket = ++releaseTicket;
		Minecraft client = minecraft;
		rebuild();
		CompletableFuture.supplyAsync(() -> {
			try {
				return new ReleaseOutcome(catalog.releases(project.id(), gameVersion, loader), "");
			} catch (InterruptedException error) {
				Thread.currentThread().interrupt();
				return new ReleaseOutcome(null, "Release request interrupted. Try again.");
			} catch (IOException error) {
				return new ReleaseOutcome(null, failureMessage(error));
			} catch (RuntimeException error) {
				return new ReleaseOutcome(null, "Could not load releases. Try again.");
			}
		}).thenAccept(outcome -> client.execute(() -> {
			if (client.screen != this || ticket != releaseTicket || selectedProject == null
				|| !selectedProject.id().equals(project.id())) return;
			releaseLoading = false;
			releaseError = outcome.error();
			if (outcome.releases() != null) {
				releases = outcome.releases();
				if (!releases.isEmpty()) selectedRelease = releases.get(0);
			}
			rebuild();
		}));
	}

	private void reviewSelection() {
		String link = selectionLink();
		if (link != null) HgnCompat.openUrl(link);
	}

	private String selectionLink() {
		return selectedProject == null || selectedRelease == null ? null
			: HgnModsLauncherLink.fromEnvironmentSelection(selectedProject.id(), selectedRelease.id());
	}

	private List<HgnModCatalog.Project> visibleProjects() {
		int first = projectPage * layout.projectRowsPerPage();
		return projects.subList(first,
			Math.min(projects.size(), first + layout.projectRowsPerPage()));
	}

	private static String failureMessage(IOException error) {
		String message = error.getMessage();
		return message == null || message.isBlank()
			? "Could not reach Modrinth. Check the connection and retry."
			: message;
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		HgnScreenBackdrop.render(this, graphics, mouseX, mouseY);
		HgnSurface.panel(graphics, layout.panel(), false);
		int headerX = layout.panel().x() + (layout.compact() ? 7 : 13);
		int headerY = layout.panel().y() + (layout.compact() ? 4 : 8);
		int iconSize = layout.compact() ? 12 : 21;
		HgnIcon.MODS.draw(graphics, headerX, headerY, iconSize, HgnPalette.CYAN);
		HgnTypography.fitted(graphics, font, "HGN / MOD CATALOGUE", headerX + iconSize + 5,
			headerY + (layout.compact() ? 1 : 3),
			layout.panel().width() - iconSize - (layout.compact() ? 20 : 180),
			layout.compact() ? 0.9f : 1.2f, HgnPalette.CYAN);
		if (!layout.compact()) HgnTypography.fitted(graphics, font,
			"MODRINTH  /  " + loader.toUpperCase(Locale.ROOT) + "  /  " + gameVersion,
			layout.panel().right() - 165, headerY + 5, 150, 0.72f, HgnPalette.mutedText());
		if (layout.compact()) {
			if (selectedProject == null) renderProjects(graphics, mouseX, mouseY);
			else renderReleases(graphics, mouseX, mouseY);
		} else {
			renderProjects(graphics, mouseX, mouseY);
			renderReleases(graphics, mouseX, mouseY);
		}
		super.render(graphics, mouseX, mouseY, partialTick);
	}

	private void renderProjects(GuiGraphics graphics, int mouseX, int mouseY) {
		HgnRect panel = layout.projectsPanel();
		HgnSurface.dashboardInset(graphics, panel, false);
		HgnTypography.fitted(graphics, font, "COMPATIBLE MODS", panel.x() + 5,
			panel.y() + (layout.compact() ? 4 : 5), panel.width() - 12,
			layout.compact() ? 0.78f : 0.9f, HgnPalette.CYAN);
		if (!layout.compact()) HgnTypography.fitted(graphics, font,
			"Modrinth projects for " + loader + " " + gameVersion,
			panel.x() + 5, panel.y() + 17, panel.width() - 10,
			0.7f, HgnPalette.mutedText());
		List<HgnModCatalog.Project> visible = visibleProjects();
		for (int row = 0; row < visible.size(); row++) {
			HgnModCatalog.Project project = visible.get(row);
			HgnRect bounds = layout.projectRow(row);
			boolean selected = selectedProject != null && selectedProject.id().equals(project.id());
			HgnSurface.dashboardInset(graphics, bounds, selected || bounds.contains(mouseX, mouseY));
			HgnTypography.fitted(graphics, font, project.title(), bounds.x() + 5,
				bounds.y() + (layout.compact() ? 3 : 2), bounds.width() - 10,
				layout.compact() ? 0.82f : 0.85f,
				selected ? HgnPalette.CYAN : HgnPalette.TEXT);
			if (!layout.compact() && !project.author().isEmpty()) HgnTypography.fitted(
				graphics, font, "by " + project.author(), bounds.x() + 5,
				bounds.y() + 11, bounds.width() - 10, 0.65f, HgnPalette.mutedText());
		}
		if (visible.isEmpty()) HgnTypography.fitted(graphics, font,
			searchLoading ? "Searching Modrinth..."
				: !searchError.isEmpty() ? searchError
				: totalHits == 0 ? "No compatible mods found."
				: "No readable mod listings on this page.",
			layout.projectList().x() + 4, layout.projectList().y() + 5,
			layout.projectList().width() - 8, 0.8f,
			searchError.isEmpty() ? HgnPalette.mutedText() : HgnPalette.DANGER);
		HgnTypography.fitted(graphics, font,
			searchLoading ? "LOADING" : totalHits + " RESULTS",
			panel.x() + 5, layout.projectPrevious().y() + (layout.compact() ? 4 : 5),
			layout.projectPrevious().x() - panel.x() - 10, 0.72f, HgnPalette.mutedText());
	}

	private void renderReleases(GuiGraphics graphics, int mouseX, int mouseY) {
		HgnRect panel = layout.releasesPanel();
		HgnSurface.dashboardInset(graphics, panel, false);
		String title = selectedProject == null ? "SELECT A MOD" : selectedProject.title();
		HgnTypography.fitted(graphics, font, title, panel.x() + 5, panel.y() + 5,
			panel.width() - 10, layout.compact() ? 0.85f : 1.0f, HgnPalette.CYAN);
		if (selectedProject != null) {
			String target = "LISTED RELEASES  /  " + loader.toUpperCase(Locale.ROOT)
				+ "  /  " + gameVersion;
			HgnTypography.fitted(graphics, font, target, panel.x() + 5,
				panel.y() + (layout.compact() ? 16 : 20), panel.width() - 10,
				0.7f, HgnPalette.mutedText());
			if (!layout.compact() && !selectedProject.description().isEmpty()) {
				HgnTypography.fitted(graphics, font, selectedProject.description(),
					panel.x() + 5, panel.y() + 34, panel.width() - 10,
					0.68f, HgnPalette.TEXT);
			}
		}
		int first = releasePage * layout.releaseRowsPerPage();
		int last = Math.min(releases.size(), first + layout.releaseRowsPerPage());
		for (int index = first; index < last; index++) {
			HgnModCatalog.Release release = releases.get(index);
			HgnRect bounds = layout.releaseRow(index - first);
			boolean selected = selectedRelease != null && selectedRelease.id().equals(release.id());
			HgnSurface.dashboardInset(graphics, bounds, selected || bounds.contains(mouseX, mouseY));
			HgnTypography.fitted(graphics, font, release.label(), bounds.x() + 5,
				bounds.y() + (layout.compact() ? 3 : 2), bounds.width() - 10,
				layout.compact() ? 0.78f : 0.8f,
				selected ? HgnPalette.CYAN : HgnPalette.TEXT);
			if (!layout.compact() && !release.publishedAt().isEmpty()) {
				String published = release.publishedAt();
				HgnTypography.fitted(graphics, font,
					published.substring(0, Math.min(10, published.length())),
					bounds.x() + 5, bounds.y() + 11, bounds.width() - 10,
					0.63f, HgnPalette.mutedText());
			}
		}
		if (first == last) HgnTypography.fitted(graphics, font,
			selectedProject == null ? "Choose a mod to see its compatible releases."
				: releaseLoading ? "Loading compatible releases..."
				: !releaseError.isEmpty() ? releaseError
				: "No compatible listed releases.",
			layout.releaseList().x() + 4, layout.releaseList().y() + 5,
			layout.releaseList().width() - 8, 0.8f,
			releaseError.isEmpty() ? HgnPalette.mutedText() : HgnPalette.DANGER);
		HgnTypography.fitted(graphics, font,
			releaseLoading ? "LOADING" : releases.size() + " RELEASES",
			panel.x() + 5, layout.releasePrevious().y() + (layout.compact() ? 4 : 5),
			layout.releasePrevious().x() - panel.x() - 10,
			0.72f, HgnPalette.mutedText());
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}

	private record SearchOutcome(HgnModCatalog.SearchResult result, String error) {
	}

	private record ReleaseOutcome(List<HgnModCatalog.Release> releases, String error) {
	}
}
