package online.horizongate.hgn.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerStatusPinger;
import net.minecraft.network.chat.Component;
import online.horizongate.hgn.HgnClient;
import online.horizongate.hgn.HgnOfficialServers;
import online.horizongate.hgn.compat.HgnCompat;
import online.horizongate.hgn.compat.HgnDraw;
import online.horizongate.hgn.ui.HgnDashboardLayout;
import online.horizongate.hgn.ui.HgnIcon;
import online.horizongate.hgn.ui.HgnMultiplayerLayout;
import online.horizongate.hgn.ui.HgnPalette;
import online.horizongate.hgn.ui.HgnRect;
import online.horizongate.hgn.ui.HgnScreenBackdrop;
import online.horizongate.hgn.ui.HgnServerPopulation;
import online.horizongate.hgn.ui.HgnSurface;
import online.horizongate.hgn.ui.dashboard.HgnTypography;
import online.horizongate.hgn.ui.widget.HgnButton;

/** Network discovery, individual server cards and a separate connection inspector. */
public final class HgnMultiplayerScreen extends Screen {
	private final Screen parent;
	private boolean networkOpen = true;
	private boolean compact;
	private int selected;
	private String searchQuery = "";
	private EditBox searchBox;
	private HgnDashboardLayout layout;
	private final List<ServerData> statuses = new ArrayList<>();
	private ServerStatusPinger pinger;
	private ExecutorService executor;
	private long refreshStarted;
	private volatile long pingGeneration;
	private HgnButton joinButton;
	private final online.horizongate.hgn.ui.HgnDoubleClick serverClicks = new online.horizongate.hgn.ui.HgnDoubleClick();

	public HgnMultiplayerScreen(Screen parent) {
		super(Component.literal("HGN Multiplayer"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		layout = HgnDashboardLayout.resolve(width, height);
		compact = HgnMultiplayerLayout.compact(width, height);
		if (pinger == null) refreshStatus();
		rebuild();
	}

	private void rebuild() {
		clearWidgets();
		if (compact) {
			rebuildCompact();
			return;
		}
		button(30, 116, 148, 30, "Official servers", HgnIcon.SERVERS, networkOpen,
			() -> { serverClicks.reset(); networkOpen = true; rebuild(); });
		button(30, 154, 148, 30, "Network overview", HgnIcon.MULTIPLAYER, !networkOpen,
			() -> { serverClicks.reset(); networkOpen = false; rebuild(); });
		button(30, 215, 148, 30, "Saved servers", HgnIcon.WORLD, false, this::openSaved);
		button(30, 253, 148, 30, "LAN games", HgnIcon.SERVERS, false, this::openLan);
		button(30, 291, 148, 30, "Direct connect", HgnIcon.LINK, false, this::directConnect);
		button(30, 393, 148, 28, "Main menu", HgnIcon.BACK, false, this::onClose);
		button(688, networkOpen ? 104 : 54, 112, networkOpen ? 27 : 24,
			"Refresh", HgnIcon.SERVERS, false, () -> {
			if (System.nanoTime() - refreshStarted > 2_000_000_000L) refreshStatus();
		});
		if (!networkOpen) {
			HgnRect hero = layout.rect(207, 108, 595, 195);
			addRenderableWidget(HgnButton.hitTarget(hero.x(), hero.y(), hero.width(), hero.height(),
				Component.literal("Browse all HorizonGate Network servers"), ignored -> {
					serverClicks.reset(); networkOpen = true; rebuild();
				}));
			button(232, 252, 226, 29, "Explore servers", HgnIcon.PLAY, true,
				() -> { serverClicks.reset(); networkOpen = true; rebuild(); });
			button(227, 365, 233, 29, "Open saved servers", HgnIcon.WORLD, false, this::openSaved);
			joinButton = null;
		} else {
			searchBox = addSearch(layout.rect(HgnMultiplayerLayout.search()));
			List<Integer> matches = matchedServers();
			for (int position = 0; position < matches.size(); position++) {
				int choice = matches.get(position);
				HgnRect card = layout.rect(HgnMultiplayerLayout.serverCard(position));
				addRenderableWidget(HgnButton.hitTarget(card.x(), card.y(), card.width(), card.height(),
					Component.literal("Select " + HgnOfficialServers.ALL.get(choice).name()), ignored -> {
						selectServer(choice);
					}));
			}
			HgnRect join = HgnMultiplayerLayout.join();
			joinButton = button(join.x(), join.y(), join.width(), join.height(),
				joinLabel(), HgnIcon.PLAY, true, this::join);
			joinButton.active = !matches.isEmpty();
		}
	}

	private void rebuildCompact() {
		compactButton(HgnMultiplayerLayout.compactRefresh(width), "Refresh", false, () -> {
			if (System.nanoTime() - refreshStarted > 2_000_000_000L) refreshStatus();
		});
		for (int index = 0; index < HgnMultiplayerLayout.COMPACT_NAVIGATION_COUNT; index++) {
			int choice = index;
			compactButton(HgnMultiplayerLayout.compactNavigation(width, index),
				HgnMultiplayerLayout.compactNavigationLabel(index),
				HgnMultiplayerLayout.compactNavigationSelected(index, networkOpen), () -> {
					switch (choice) {
						case 0, 1 -> {
							serverClicks.reset();
							networkOpen = HgnMultiplayerLayout.compactShowsOfficialServers(choice);
							rebuild();
						}
						case 2 -> openSaved();
						case 3 -> openLan();
						default -> onClose();
					}
				});
		}
		if (!networkOpen) {
			compactButton(HgnMultiplayerLayout.compactExplore(width, height),
				"Explore official servers", true, () -> {
					serverClicks.reset(); networkOpen = true; rebuild();
				});
			joinButton = null;
			return;
		}
		searchBox = addSearch(HgnMultiplayerLayout.compactSearch(width));
		List<Integer> matches = matchedServers();
		for (int position = 0; position < matches.size(); position++) {
			int choice = matches.get(position);
			HgnRect card = HgnMultiplayerLayout.compactServerCard(width, height, position);
			addRenderableWidget(HgnButton.hitTarget(card.x(), card.y(), card.width(), card.height(),
				Component.literal("Select " + HgnOfficialServers.ALL.get(choice).name()),
				ignored -> selectServer(choice)));
		}
		joinButton = compactButton(HgnMultiplayerLayout.compactJoin(width, height),
			joinLabel(), true, this::join);
		joinButton.active = !matches.isEmpty();
	}

	private EditBox addSearch(HgnRect bounds) {
		EditBox box = new EditBox(font, bounds.x(), bounds.y(), bounds.width(), bounds.height(),
			Component.literal("Search official servers"));
		box.setMaxLength(100);
		box.setValue(searchQuery);
		box.setResponder(value -> {
			searchQuery = value;
			List<Integer> matches = matchedServers();
			if (!matches.isEmpty() && !matches.contains(selected)) selected = matches.get(0);
			serverClicks.reset();
			rebuild();
			if (searchBox != null) setInitialFocus(searchBox);
		});
		return addRenderableWidget(box);
	}

	private List<Integer> matchedServers() {
		List<Integer> matches = new ArrayList<>();
		for (int index = 0; index < HgnOfficialServers.ALL.size(); index++) {
			var server = HgnOfficialServers.ALL.get(index);
			if (HgnMultiplayerLayout.matches(searchQuery, server.name(), server.id(),
				server.address(), server.blurb())) matches.add(index);
		}
		return matches;
	}

	private HgnButton compactButton(HgnRect bounds, String label, boolean primary, Runnable action) {
		return addRenderableWidget(HgnButton.dashboardCentered(bounds.x(), bounds.y(),
			bounds.width(), bounds.height(), Component.literal(label), primary,
			ignored -> action.run()).referenceScale(1.0f));
	}

	private void openSaved() { minecraft.setScreen(new HgnSavedServersScreen(this)); }

	private void openLan() { minecraft.setScreen(new HgnSavedServersScreen(this, true)); }

	private void directConnect() {
		minecraft.setScreen(new HgnServerEditorScreen(this, null, null, true));
	}

	private void selectServer(int choice) {
		boolean doubleClick = serverClicks.activate(choice, System.nanoTime());
		selected = choice;
		if (doubleClick) join();
	}

	private String joinLabel() {
		if (!matchedServers().contains(selected)) return "Select a server";
		return HgnOfficialServers.ALL.get(selected).playableNow() ? "Join server" : "Switch in launcher";
	}

	private void join() {
		if (!matchedServers().contains(selected)) return;
		var server = HgnOfficialServers.ALL.get(selected);
		if (server.playableNow()) HgnCompat.connect(this, minecraft, server.name(), server.address());
		else HgnCompat.openUrl("hgn://play/" + server.id() + "/" + server.requiredVersion());
	}

	private void refreshStatus() {
		serverClicks.reset();
		stopPings();
		statuses.clear();
		pinger = new ServerStatusPinger();
		ServerStatusPinger activePinger = pinger;
		long generation = pingGeneration;
		executor = Executors.newFixedThreadPool(2, task -> {
			Thread thread = new Thread(task, "HGN server status");
			thread.setDaemon(true);
			return thread;
		});
		refreshStarted = System.nanoTime();
		for (var server : HgnOfficialServers.ALL) {
			ServerData data = new ServerData(server.name(), server.address(), ServerData.Type.OTHER);
			data.ping = -2L;
			statuses.add(data);
			executor.execute(() -> {
				try {
					if (generation == pingGeneration) HgnCompat.pingServer(activePinger, data, () -> {}, () -> {});
				} finally {
					if (generation != pingGeneration) activePinger.removeAll();
				}
			});
		}
	}

	@Override
	public void tick() {
		if (pinger != null) pinger.tick();
		if (joinButton != null) joinButton.setMessage(Component.literal(joinLabel()));
	}

	private void stopPings() {
		pingGeneration++;
		if (executor != null) { executor.shutdownNow(); executor = null; }
		if (pinger != null) { pinger.removeAll(); pinger = null; }
	}

	@Override
	public void removed() { serverClicks.reset(); stopPings(); }

	@Override
	public void onClose() { minecraft.setScreen(parent); }

	private HgnButton button(int x, int y, int w, int h, String label, HgnIcon icon,
		boolean primary, Runnable action) {
		HgnRect bounds = layout.rect(x, y, w, h);
		return addRenderableWidget(HgnButton.dashboardCommand(bounds.x(), bounds.y(),
			bounds.width(), bounds.height(), Component.literal(label), icon, primary,
			ignored -> action.run()).referenceScale(
				HgnMultiplayerLayout.buttonTextScale(layout.scale()),
				HgnMultiplayerLayout.buttonIconScale(layout.scale())));
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		HgnScreenBackdrop.render(this, graphics, mouseX, mouseY);
		if (compact) {
			renderCompact(graphics, mouseX, mouseY);
			super.render(graphics, mouseX, mouseY, partialTick);
			return;
		}
		panel(graphics, 18, 40, 172, 397, false);
		panel(graphics, 199, 40, 613, 53, false);
		text(graphics, "MULTIPLAYER", 214, 53, HgnMultiplayerLayout.TITLE_EMPHASIS, HgnPalette.TEXT);
		text(graphics, networkOpen ? "HorizonGate Network / live server browser" : "Discover your next world",
			214, 75, 0.76f, HgnPalette.TEXT_MUTED);
		text(graphics, "HGN / CONNECT", 32, 60, 1.05f, HgnPalette.CYAN);
		text(graphics, "NETWORK", 32, 94, 0.75f, HgnPalette.TEXT_MUTED);
		text(graphics, "YOUR SERVERS", 32, 198, 0.75f, HgnPalette.TEXT_MUTED);
		text(graphics, "Minecraft " + HgnClient.minecraftVersion(), 32, 365, 0.72f, HgnPalette.TEXT_MUTED);
		if (networkOpen) renderServers(graphics, mouseX, mouseY);
		else renderDiscovery(graphics, mouseX, mouseY);
		super.render(graphics, mouseX, mouseY, partialTick);
	}

	private void renderCompact(GuiGraphics graphics, int mouseX, int mouseY) {
		HgnSurface.panel(graphics, HgnMultiplayerLayout.compactHeader(width), false);
		compactText(graphics, "HGN SERVERS", 16, 12, 1.05f, HgnPalette.TEXT);
		HgnSurface.panel(graphics, HgnMultiplayerLayout.compactContent(width, height), false);
		if (!networkOpen) {
			compactText(graphics, "HORIZONGATE NETWORK", 16, 75, 1.1f, HgnPalette.TEXT);
			compactText(graphics, HgnOfficialServers.ALL.size() + " official destinations", 16, 94,
				1.0f, HgnPalette.CYAN);
			compactFit(graphics, "Choose a server to inspect its connection and version.",
				16, 112, width - 32, 0.95f, HgnPalette.TEXT_MUTED);
			return;
		}
		List<Integer> matches = matchedServers();
		for (int position = 0; position < matches.size(); position++) {
			int index = matches.get(position);
			var server = HgnOfficialServers.ALL.get(index);
			HgnRect card = HgnMultiplayerLayout.compactServerCard(width, height, position);
			HgnSurface.panel(graphics, card, selected == index || card.contains(mouseX, mouseY));
			int imageSize = Math.min(36, card.height() - 6);
			int sourceSize = serverImageSize(server.id());
			HgnDraw.textureStretch(graphics, "textures/gui/servers/server-" + server.id() + ".png",
				card.x() + 5, card.y() + (card.height() - imageSize) / 2,
				imageSize, imageSize, sourceSize, sourceSize);
			int textY = card.y() + Math.max(5, (card.height() - 28) / 2);
			compactFit(graphics, server.name(), card.x() + 47, textY, card.width() - 55,
				0.98f, HgnPalette.TEXT);
			compactFit(graphics, status(index) + " / " + server.versionLabel(), card.x() + 47,
				textY + 15, card.width() - 55, 0.95f, HgnPalette.TEXT_MUTED);
		}
		if (matches.isEmpty()) compactFit(graphics, "No matching official servers", 16, 78,
			width - 32, 0.95f, HgnPalette.TEXT_MUTED);
		HgnRect join = HgnMultiplayerLayout.compactJoin(width, height);
		if (matches.isEmpty()) return;
		HgnRect lastCard = HgnMultiplayerLayout.compactServerCard(width, height, matches.size() - 1);
		int detailRoom = join.y() - lastCard.bottom();
		var selectedServer = HgnOfficialServers.ALL.get(selected);
		if (detailRoom >= 18) {
			compactFit(graphics, selectedServer.address(), 16, lastCard.bottom() + 7,
				width - 32, 0.95f, HgnPalette.TEXT_MUTED);
		}
		if (detailRoom >= 32) {
			compactFit(graphics, selectedServer.blurb(), 16, lastCard.bottom() + 21,
				width - 32, 0.95f, HgnPalette.TEXT_MUTED);
		}
		compactFit(graphics, status(selected), 16, join.y() + 7, join.x() - 24,
			0.95f, HgnPalette.CYAN);
	}

	private void compactText(GuiGraphics graphics, String value, int x, int y,
		float size, int color) {
		HgnTypography.text(graphics, font, value, x, y, size, color);
	}

	private void compactFit(GuiGraphics graphics, String value, int x, int y,
		int available, float size, int color) {
		compactText(graphics, HgnTypography.trim(font, value,
			Math.max(1, (int) (available / size))), x, y, size, color);
	}

	private void renderDiscovery(GuiGraphics graphics, int mouseX, int mouseY) {
		panel(graphics, 207, 108, 595, 195, layout.rect(207, 108, 595, 195).contains(mouseX, mouseY));
		image(graphics, "server-hub.png", 655, 134, 113);
		text(graphics, "FEATURED NETWORK", 232, 131, 0.75f, HgnPalette.CYAN);
		text(graphics, "HORIZONGATE", 232, 156, 1.7f, HgnPalette.TEXT);
		text(graphics, "NETWORK", 232, 178, 1.7f, HgnPalette.TEXT);
		text(graphics, "One community. Choose your adventure.", 232, 213, 0.91f, HgnPalette.TEXT_MUTED);
		text(graphics, HgnOfficialServers.ALL.size() + " official destinations", 232, 232, 0.78f, HgnPalette.CYAN);
		text(graphics, "NETWORK PLAYERS", 623, 259, 0.7f, HgnPalette.CYAN);
		text(graphics, "Count unavailable", 623, 277, 0.78f, HgnPalette.TEXT_MUTED);
		panel(graphics, 207, 317, 277, 110, false);
		panel(graphics, 496, 317, 306, 110, false);
		text(graphics, "YOUR SAVED SERVERS", 227, 334, 0.94f, HgnPalette.TEXT);
		text(graphics, "Friends, servers and LAN", 227, 349, 0.68f, HgnPalette.TEXT_MUTED);
		text(graphics, "BUILT FOR YOUR NEXT SESSION", 514, 337, 0.89f, HgnPalette.CYAN);
		text(graphics, "Choose a server to inspect its connection", 514, 361, 0.77f, HgnPalette.TEXT_MUTED);
		text(graphics, "and Minecraft version before joining.", 514, 377, 0.77f, HgnPalette.TEXT_MUTED);
		text(graphics, "Saved in Minecraft's server list.", 514, 401, 0.69f, HgnPalette.TEXT_MUTED);
	}

	private void renderServers(GuiGraphics graphics, int mouseX, int mouseY) {
		List<Integer> matches = matchedServers();
		fit(graphics, matches.size() + " official", 584, 113, 99, 0.76f, HgnPalette.CYAN);
		for (int position = 0; position < matches.size(); position++) {
			int index = matches.get(position);
			var server = HgnOfficialServers.ALL.get(index);
			HgnRect card = HgnMultiplayerLayout.serverCard(position);
			int y = card.y();
			panel(graphics, card.x(), y, card.width(), card.height(), selected == index
				|| layout.rect(card).contains(mouseX, mouseY));
			image(graphics, "server-" + server.id() + ".png", 219, y + 15, 78);
			fit(graphics, server.name(), 309, y + 18, 250, 1.05f, HgnPalette.TEXT);
			fit(graphics, server.blurb(), 309, y + 43, 250, 0.72f, HgnPalette.TEXT_MUTED);
			text(graphics, status(index), 309, y + 70, 0.76f, HgnPalette.CYAN);
			fit(graphics, players(index), 309, y + 90, 245, 0.71f, HgnPalette.TEXT_MUTED);
			text(graphics, "Minecraft " + server.versionLabel(), 219, y + 108, 0.71f, HgnPalette.TEXT_MUTED);
		}
		if (matches.isEmpty()) {
			panel(graphics, 207, 145, 365, 128, false);
			text(graphics, "NO MATCHING SERVERS", 224, 169, 1.0f, HgnPalette.TEXT);
			text(graphics, "Try another name or server address.", 224, 196, 0.75f, HgnPalette.TEXT_MUTED);
		}
		HgnRect inspector = HgnMultiplayerLayout.inspector();
		panel(graphics, inspector.x(), inspector.y(), inspector.width(), inspector.height(), false);
		text(graphics, "CONNECTION DETAILS", 599, 161, 0.77f, HgnPalette.CYAN);
		if (matches.isEmpty()) {
			fit(graphics, "Select an official server", 599, 200, 188, 0.9f, HgnPalette.TEXT_MUTED);
			return;
		}
		var server = HgnOfficialServers.ALL.get(selected);
		image(graphics, "server-" + server.id() + ".png", 653, 183, 74);
		fit(graphics, server.name(), 599, 270, 188, 0.95f, HgnPalette.TEXT);
		fit(graphics, server.address(), 599, 291, 188, 0.72f, HgnPalette.TEXT_MUTED);
		fit(graphics, status(selected), 599, 312, 188, 0.75f, HgnPalette.CYAN);
		fit(graphics, players(selected), 599, 330, 188, 0.69f, HgnPalette.TEXT_MUTED);
		fit(graphics, server.playableNow() ? "MC " + server.versionLabel() + " / ready"
			: "Requires Minecraft " + server.requiredVersion(), 599, 351, 188, 0.69f,
			server.playableNow() ? HgnPalette.TEXT_MUTED : HgnPalette.WARNING);
	}

	private String players(int index) {
		ServerData data = index < statuses.size() ? statuses.get(index) : null;
		return HgnServerPopulation.fromMinecraftPing(true,
			data == null || data.players == null ? -1 : data.players.online(),
			data == null || data.players == null ? -1 : data.players.max());
	}

	private String status(int index) {
		if (index >= statuses.size()) return "Status unavailable";
		ServerData data = statuses.get(index);
		if (data.ping >= 0L) return "Online  /  " + data.ping + " ms";
		return System.nanoTime() - refreshStarted < 10_000_000_000L ? "Checking connection..." : "Unreachable / retry available";
	}

	private void panel(GuiGraphics graphics, int x, int y, int w, int h, boolean active) {
		HgnSurface.panel(graphics, layout.rect(x, y, w, h), active);
	}

	private void image(GuiGraphics graphics, String file, int x, int y, int size) {
		int sourceSize = file.equals("server-hub.png") ? 1254 : 256;
		HgnDraw.textureStretch(graphics, "textures/gui/servers/" + file,
			layout.x(x), layout.y(y), layout.size(size), layout.size(size), sourceSize, sourceSize);
	}

	private int serverImageSize(String serverId) {
		return serverId.equals("hub") ? 1254 : 256;
	}

	private void text(GuiGraphics graphics, String value, int x, int y, float size, int color) {
		HgnTypography.text(graphics, font, value, layout.x(x), layout.y(y),
			HgnMultiplayerLayout.textScale(layout.scale(), size), color);
	}

	private void fit(GuiGraphics graphics, String value, int x, int y, int width, float size, int color) {
		float textScale = HgnMultiplayerLayout.textScale(layout.scale(), size);
		int available = Math.max(1, layout.x(x + width) - layout.x(x));
		text(graphics, HgnTypography.trim(font, value, (int) (available / textScale)), x, y, size, color);
	}
}
