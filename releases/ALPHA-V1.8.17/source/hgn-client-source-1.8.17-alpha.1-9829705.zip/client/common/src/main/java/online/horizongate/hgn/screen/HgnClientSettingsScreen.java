package online.horizongate.hgn.screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import online.horizongate.hgn.HgnConfig;
import online.horizongate.hgn.HgnEntityRenderBudget;
import online.horizongate.hgn.net.HgnMessages;
import online.horizongate.hgn.ui.HgnPalette;
import online.horizongate.hgn.ui.HgnRect;
import online.horizongate.hgn.ui.HgnScreenBackdrop;
import online.horizongate.hgn.ui.HgnSettingsLayout;
import online.horizongate.hgn.ui.HgnSurface;
import online.horizongate.hgn.ui.dashboard.HgnTypography;
import online.horizongate.hgn.ui.widget.HgnButton;

import java.util.ArrayList;
import java.util.List;

/** Player-facing controls for HGN presentation and bounded render quality. */
public final class HgnClientSettingsScreen extends Screen {
	private final Screen parent;
	private int section;
	private int page;
	private HgnSettingsLayout layout;
	private final List<HgnButton> rowButtons = new ArrayList<>();
	private static final int[][] GROUPS = {{0, 1, 12}, {8, 9, 10}, {5, 11}, {2, 4, 7}, {3, 6}};
	private static final String[] GROUP_LABELS = {"HUD", "INFO", "PERF", "VISUAL", "ACCESS"};
	private static final String[] GROUP_TITLES = {"HUD appearance", "Gameplay readouts",
		"Performance", "Visual effects", "Accessibility"};
	private static final String[] SETTING_TITLES = {"Show HGN HUD", "HUD size", "Interface motion",
		"Reduced motion", "Scene particles", "Effect quality", "High contrast", "Hotbar & boss frames",
		"Performance readout", "World information", "Show coordinates", "Crowded drops & XP",
		"Experimental HGN hotbar"};
	private static final String[] SETTING_DETAILS = {"Show HGN gameplay readouts and frames.",
		"Cycle through compact, standard and large.", "Allow motion in supported HGN effects.",
		"Limit motion even when animations are on.", "Allow decorative HGN scene particles.",
		"Cycle the detail budget for HGN effects.", "Brighten HGN borders and help text.",
		"Frame the hotbar and boss health bars.", "Show FPS, ping and clicks per second.",
		"Show game mode, client version and biome.", "Turn off to hide your position on stream.",
		"Reduce distant drop and XP drawing in crowds; entities stay loaded.",
		"Replace the hotbar frame while keeping live Minecraft items and indicators."};

	public HgnClientSettingsScreen(Screen parent) {
		super(Component.literal("HGN Client Settings"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		rebuild();
	}

	private void rebuild() {
		rebuild(-1);
	}

	private void rebuild(int focusSetting) {
		clearWidgets();
		rowButtons.clear();
		layout = HgnSettingsLayout.resolve(width, height, GROUPS[section].length, true);
		page = Math.max(0, Math.min(page, layout.pages(GROUPS[section].length) - 1));
		for (int index = 0; index < GROUP_LABELS.length; index++) {
			int choice = index;
			button(layout.tab(index, GROUP_LABELS.length), GROUP_LABELS[index], section == index,
				() -> { section = choice; page = 0; rebuild(); setFocused(children().get(choice)); });
		}
		int first = page * layout.rowsPerPage();
		for (int row = 0; row < layout.rowsPerPage() && first + row < GROUPS[section].length; row++) {
			int setting = GROUPS[section][first + row];
			HgnRect bounds = layout.row(row);
			HgnButton control = addRenderableWidget(HgnButton.hitTarget(bounds.x(), bounds.y(),
				bounds.width(), bounds.height(), Component.literal(SETTING_TITLES[setting] + ": "
					+ settingLabel(setting) + ". " + settingDetail(setting)), ignored -> changeSetting(setting)));
			rowButtons.add(control);
			if (setting == focusSetting) setFocused(control);
		}
		int pages = layout.pages(GROUPS[section].length);
		if (pages > 1) {
			button(layout.pageButton(false), "Previous", false,
				() -> { page--; rebuild(); focusFirstRow(); }).active = page > 0;
			button(layout.pageButton(true), "Next", false,
				() -> { page++; rebuild(); focusFirstRow(); }).active = page + 1 < pages;
		}
		button(layout.footerButton(0, 2), "Minecraft settings", false,
			() -> minecraft.setScreen(new OptionsScreen(this, minecraft.options)));
		button(layout.footerButton(1, 2), "Done", true, this::onClose);
	}

	private void focusFirstRow() {
		if (!rowButtons.isEmpty()) setFocused(rowButtons.getFirst());
	}

	private HgnButton button(HgnRect bounds, String label, boolean selected, Runnable action) {
		return addRenderableWidget(HgnButton.dashboardCentered(bounds.x(), bounds.y(),
			bounds.width(), bounds.height(), Component.literal(label), selected, ignored -> action.run())
			.referenceScale(1.0f));
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		HgnScreenBackdrop.render(this, graphics, mouseX, mouseY);
		HgnSurface.panel(graphics, layout.panel(), false);
		int left = layout.content().x();
		int lane = layout.content().width();
		text(graphics, layout.compact() ? "HGN SETTINGS / AUTO SAVE" : "HGN / CLIENT SETTINGS",
			left, layout.headerTitleY(), lane, 1.2f, HgnPalette.TEXT);
		if (!layout.compact()) text(graphics, "Saved automatically to this profile.", left,
			layout.panel().y() + 34, lane, 0.95f, HgnPalette.mutedText());
		int pages = layout.pages(GROUPS[section].length);
		text(graphics, pages > 1 ? GROUP_LABELS[section] : GROUP_TITLES[section], left, layout.sectionTitleY(),
			lane - (pages > 1 ? 154 : 0), 1.05f, HgnPalette.CYAN);
		if (pages > 1) HgnTypography.centered(graphics, font, (page + 1) + " / " + pages,
			layout.content().right() - 66, layout.sectionTitleY(), HgnPalette.TEXT);
		for (int row = 0; row < rowButtons.size(); row++) {
			int setting = GROUPS[section][page * layout.rowsPerPage() + row];
			HgnRect bounds = layout.row(row);
			HgnSurface.dashboardInset(graphics, bounds, rowButtons.get(row).isHoveredOrFocused());
			int textWidth = bounds.width() - 122;
			text(graphics, HgnTypography.trim(font, SETTING_TITLES[setting], textWidth),
				bounds.x() + 12, layout.rowTitleY(row), textWidth, 1.0f, HgnPalette.TEXT);
			HgnRect value = layout.settingValue(row);
			HgnSurface.control(graphics, value, 0, false, true, false, false);
			HgnTypography.centered(graphics, font, settingLabel(setting), value.centerX(),
				value.y() + (layout.compact() ? 6 : 8), HgnPalette.CYAN);
			if (layout.showsRowHelp()) text(graphics,
				HgnTypography.trim(font, settingDetail(setting), textWidth), bounds.x() + 12,
				layout.rowHelpY(row), textWidth, 0.95f, HgnPalette.mutedText());
		}
		super.render(graphics, mouseX, mouseY, partialTick);
	}

	private void text(GuiGraphics graphics, String value, int x, int y, int width, float size, int color) {
		HgnTypography.fitted(graphics, font, value, x, y, width, size, color);
	}

	private String settingLabel(int index) {
		HgnConfig config = HgnConfig.get();
		return switch (index) {
			case 0 -> toggle(config.hudEnabled);
			case 1 -> config.hudSize.name();
			case 2 -> toggle(config.interfaceAnimations);
			case 3 -> toggle(config.reducedMotion);
			case 4 -> toggle(config.sceneParticles);
			case 5 -> config.sceneQuality.name();
			case 6 -> toggle(config.highContrast);
			case 7 -> toggle(config.hudFrames);
			case 8 -> toggle(config.hudPerformance);
			case 9 -> toggle(config.hudContext);
			case 10 -> toggle(config.hudCoordinates);
			case 11 -> toggle(config.crowdedItemRendering);
			case 12 -> toggle(config.experimentalHgnHotbar);
			default -> "HGN";
		};
	}

	private String toggle(boolean enabled) {
		return enabled ? "ON" : "OFF";
	}

	private String settingDetail(int index) {
		if (index != 11 || !HgnConfig.get().crowdedItemRendering) return SETTING_DETAILS[index];
		long skipped = HgnEntityRenderBudget.skippedRenderChecks();
		return skipped > 0
			? "Recent: " + skipped + " distant draw checks skipped; entities stay loaded."
			: SETTING_DETAILS[index];
	}

	private void changeSetting(int index) {
		HgnConfig config = HgnConfig.get();
		switch (index) {
			case 0 -> {
				config.hudEnabled = !config.hudEnabled;
				HgnMessages.sendHudStatus(config.hudEnabled);
			}
			case 1 -> config.hudSize = next(config.hudSize);
			case 2 -> config.interfaceAnimations = !config.interfaceAnimations;
			case 3 -> config.reducedMotion = !config.reducedMotion;
			case 4 -> config.sceneParticles = !config.sceneParticles;
			case 5 -> config.sceneQuality = next(config.sceneQuality);
			case 6 -> config.highContrast = !config.highContrast;
			case 7 -> config.hudFrames = !config.hudFrames;
			case 8 -> config.hudPerformance = !config.hudPerformance;
			case 9 -> config.hudContext = !config.hudContext;
			case 10 -> config.hudCoordinates = !config.hudCoordinates;
			case 11 -> config.crowdedItemRendering = !config.crowdedItemRendering;
			case 12 -> config.experimentalHgnHotbar = !config.experimentalHgnHotbar;
			default -> { }
		}
		HgnConfig.save();
		rebuild(index);
	}

	private static HgnConfig.HudSize next(HgnConfig.HudSize value) {
		return switch (value) {
			case COMPACT -> HgnConfig.HudSize.STANDARD;
			case STANDARD -> HgnConfig.HudSize.LARGE;
			case LARGE -> HgnConfig.HudSize.COMPACT;
		};
	}

	private static HgnConfig.SceneQuality next(HgnConfig.SceneQuality value) {
		return switch (value) {
			case LOW -> HgnConfig.SceneQuality.BALANCED;
			case BALANCED -> HgnConfig.SceneQuality.HIGH;
			case HIGH -> HgnConfig.SceneQuality.LOW;
		};
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}
}
