package online.horizongate.hgn.ui;

/** Reference-sized header and navigation geometry shared by wide HGN Client menus. */
public record HgnReferenceShellLayout(HgnDashboardLayout canvas) {
	public static final int DESTINATIONS = 8;

	public HgnRect rail() {
		return canvas.rect(18, 88, 184, 351);
	}

	public HgnRect destination(int index) {
		if (index < 0 || index >= DESTINATIONS) throw new IndexOutOfBoundsException(index);
		return canvas.rect(28, 98 + index * 41, 164, 34);
	}

	public HgnRect wordmark() {
		return canvas.rect(28, 18, 73, 49);
	}

	public HgnRect versionBadge() {
		return canvas.rect(716, 11, 98, 20);
	}

	public HgnRect featuredNetwork() {
		return canvas.rect(208, 94, 425, 96);
	}

	public HgnRect featuredAction() {
		return canvas.rect(228, 161, 200, 23);
	}
}
