package online.horizongate.hgn.ui;

/** Native-pixel geometry for searching mods and choosing a compatible release. */
public record HgnModCatalogLayout(boolean compact, HgnRect panel, HgnRect search,
	HgnRect searchAction, HgnRect projectsPanel, HgnRect releasesPanel,
	HgnRect projectList, HgnRect releaseList, HgnRect projectPrevious,
	HgnRect projectNext, HgnRect releasePrevious, HgnRect releaseNext,
	HgnRect back, HgnRect openLauncher, HgnRect review,
	int projectRowHeight, int releaseRowHeight, int projectRowsPerPage,
	int releaseRowsPerPage) {
	public static HgnModCatalogLayout resolve(int width, int height) {
		int margin = clamp(Math.min(width, height) / 45, 4, 10);
		int panelWidth = Math.min(Math.max(1, width - margin * 2), 900);
		int panelHeight = Math.min(Math.max(1, height - margin * 2), 560);
		HgnRect panel = new HgnRect((width - panelWidth) / 2,
			(height - panelHeight) / 2, panelWidth, panelHeight);
		boolean compact = width < 600 || height < 330;
		int inset = compact ? 5 : 10;
		int innerX = panel.x() + inset;
		int innerWidth = Math.max(1, panel.width() - inset * 2);
		int searchY = panel.y() + (compact ? 21 : 33);
		int searchHeight = compact ? 15 : 21;
		int actionWidth = compact ? 52 : 72;
		int footerHeight = compact ? 15 : 22;
		int footerY = panel.bottom() - inset - footerHeight;
		int contentY = searchY + searchHeight + (compact ? 4 : 8);
		int contentHeight = Math.max(1, footerY - (compact ? 4 : 8) - contentY);
		int columnGap = compact ? 0 : 8;
		int projectWidth = compact ? innerWidth : (innerWidth - columnGap) * 54 / 100;
		HgnRect projectsPanel = new HgnRect(innerX, contentY, projectWidth, contentHeight);
		HgnRect releasesPanel = compact ? projectsPanel : new HgnRect(
			projectsPanel.right() + columnGap, contentY,
			innerWidth - projectWidth - columnGap, contentHeight);
		HgnRect searchAction = new HgnRect(projectsPanel.right() - actionWidth,
			searchY, actionWidth, searchHeight);
		HgnRect search = new HgnRect(innerX, searchY,
			projectsPanel.width() - actionWidth - 4, searchHeight);
		int pagerHeight = compact ? 15 : 20;
		int pagerWidth = compact ? 29 : 45;
		HgnRect projectPrevious = new HgnRect(projectsPanel.right() - 2 * pagerWidth - 7,
			projectsPanel.bottom() - pagerHeight - 3, pagerWidth, pagerHeight);
		HgnRect projectNext = new HgnRect(projectPrevious.right() + 4,
			projectPrevious.y(), pagerWidth, pagerHeight);
		HgnRect releasePrevious = new HgnRect(releasesPanel.right() - 2 * pagerWidth - 7,
			releasesPanel.bottom() - pagerHeight - 3, pagerWidth, pagerHeight);
		HgnRect releaseNext = new HgnRect(releasePrevious.right() + 4,
			releasePrevious.y(), pagerWidth, pagerHeight);
		HgnRect projectList = new HgnRect(projectsPanel.x() + 5,
			projectsPanel.y() + (compact ? 19 : 29), projectsPanel.width() - 10,
			Math.max(1, projectPrevious.y() - projectsPanel.y() - (compact ? 22 : 33)));
		HgnRect releaseList = new HgnRect(releasesPanel.x() + 5,
			releasesPanel.y() + (compact ? 30 : 54), releasesPanel.width() - 10,
			Math.max(1, releasePrevious.y() - releasesPanel.y() - (compact ? 33 : 58)));
		int projectRowHeight = Math.min(compact ? 15 : 20, projectList.height());
		int releaseRowHeight = Math.min(compact ? 15 : 20, releaseList.height());
		int rowGap = compact ? 2 : 3;
		int projectRows = Math.max(1, (projectList.height() + rowGap) / (projectRowHeight + rowGap));
		int releaseRows = Math.max(1, (releaseList.height() + rowGap) / (releaseRowHeight + rowGap));
		int backWidth = compact ? 56 : 124;
		int launcherWidth = compact ? 84 : 145;
		int reviewWidth = compact ? 130 : 210;
		HgnRect back = new HgnRect(innerX, footerY, backWidth, footerHeight);
		HgnRect openLauncher = new HgnRect(back.right() + 5, footerY,
			launcherWidth, footerHeight);
		HgnRect review = new HgnRect(innerX + innerWidth - reviewWidth,
			footerY, reviewWidth, footerHeight);
		return new HgnModCatalogLayout(compact, panel, search, searchAction,
			projectsPanel, releasesPanel, projectList, releaseList,
			projectPrevious, projectNext, releasePrevious, releaseNext,
			back, openLauncher, review, projectRowHeight, releaseRowHeight,
			projectRows, releaseRows);
	}

	public HgnRect projectRow(int index) {
		return new HgnRect(projectList.x(),
			projectList.y() + index * (projectRowHeight + (compact ? 2 : 3)),
			projectList.width(), projectRowHeight);
	}

	public HgnRect releaseRow(int index) {
		return new HgnRect(releaseList.x(),
			releaseList.y() + index * (releaseRowHeight + (compact ? 2 : 3)),
			releaseList.width(), releaseRowHeight);
	}

	private static int clamp(int value, int minimum, int maximum) {
		return Math.max(minimum, Math.min(maximum, value));
	}
}
