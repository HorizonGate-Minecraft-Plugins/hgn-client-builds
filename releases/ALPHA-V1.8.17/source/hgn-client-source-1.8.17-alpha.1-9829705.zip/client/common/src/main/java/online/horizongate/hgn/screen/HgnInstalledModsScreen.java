package online.horizongate.hgn.screen;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import online.horizongate.hgn.compat.HgnCompat;
import online.horizongate.hgn.compat.HgnScaledEditBox;
import online.horizongate.hgn.ui.HgnIcon;
import online.horizongate.hgn.ui.HgnInstalledModsLayout;
import online.horizongate.hgn.ui.HgnPalette;
import online.horizongate.hgn.ui.HgnRect;
import online.horizongate.hgn.ui.HgnScreenBackdrop;
import online.horizongate.hgn.ui.HgnSurface;
import online.horizongate.hgn.ui.dashboard.HgnTypography;
import online.horizongate.hgn.ui.widget.HgnButton;

/** Reference-led installed-mods destination with a separate Modrinth browser. */
public final class HgnInstalledModsScreen extends Screen {
	private final Screen parent;
	private HgnInstalledModsIndex.Snapshot snapshot;
	private HgnInstalledModsLayout layout;
	private List<HgnInstalledModsIndex.InstalledJar> filtered = List.of();
	private final List<HgnButton> rowButtons = new ArrayList<>();
	private String search = "";
	private String selectedFile;
	private int page;
	private boolean filterDirty;
	private EditBox searchBox;
	private EditBox selectedBox;

	public HgnInstalledModsScreen(Screen parent) {
		super(Component.literal("HGN Installed Mods"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		if (snapshot == null) snapshot = HgnInstalledModsIndex.read(minecraft.gameDirectory.toPath());
		rebuild();
	}

	@Override
	public void tick() {
		if (!filterDirty) return;
		filterDirty = false;
		rebuild();
		if (searchBox != null) searchBox.setFocused(true);
	}

	private void rebuild() {
		clearWidgets();
		rowButtons.clear();
		layout = HgnInstalledModsLayout.resolve(width, height);
		filtered = snapshot.filter(search);
		page = Math.max(0, Math.min(page, layout.pages(filtered.size()) - 1));
		HgnRect searchBounds = layout.search();
		searchBox = addRenderableWidget(new HgnScaledEditBox(font, searchBounds.x(),
			searchBounds.y(), searchBounds.width(), searchBounds.height(),
			Component.literal("Search installed mod filenames"), layout.compact() ? 0.82f : 0.95f));
		searchBox.setMaxLength(255);
		searchBox.setBordered(false);
		searchBox.setHint(HgnCompat.uiText(layout.compact() ? "Search JAR files..."
			: "Search installed JAR filenames in this instance..."));
		searchBox.setValue(search);
		searchBox.setResponder(value -> {
			if (value.equals(search)) return;
			search = value;
			page = 0;
			filterDirty = true;
		});
		int first = page * layout.rowsPerPage();
		for (int row = 0; row < layout.rowsPerPage() && first + row < filtered.size(); row++) {
			String fileName = filtered.get(first + row).fileName();
			HgnRect bounds = layout.row(row);
			rowButtons.add(addRenderableWidget(HgnButton.hitTarget(bounds.x(), bounds.y(),
				bounds.width(), bounds.height(), Component.literal("Installed JAR: " + fileName),
				button -> select(fileName))));
		}
		HgnRect detail = layout.detail();
		HgnRect file = new HgnRect(detail.x() + 6, detail.y() + (layout.compact() ? 5 : 18),
			detail.width() - 12, layout.compact() ? 12 : 17);
		selectedBox = addRenderableWidget(new HgnScaledEditBox(font, file.x(), file.y(),
			file.width(), file.height(), Component.literal("Selected exact JAR filename"),
			layout.compact() ? 0.8f : 0.95f));
		selectedBox.setMaxLength(255);
		selectedBox.setBordered(false);
		selectedBox.setValue(selectedFile == null ? "Select a JAR above to inspect its exact filename"
			: selectedFile);
		selectedBox.setEditable(false);
		button(layout.back(), layout.compact() ? "BACK" : "BACK TO MENU", this::onClose);
		button(layout.refresh(), layout.compact() ? "SCAN" : "REFRESH", () -> {
			snapshot = HgnInstalledModsIndex.read(minecraft.gameDirectory.toPath());
			if (selectedFile != null && snapshot.jars().stream()
				.noneMatch(jar -> jar.fileName().equals(selectedFile))) selectedFile = null;
			rebuild();
		});
		button(layout.manage(), layout.compact() ? "BROWSE" : "BROWSE MODS",
			() -> minecraft.setScreen(new HgnModCatalogScreen(this)));
		HgnButton previous = button(layout.previous(), layout.compact() ? "<" : "PREV",
			() -> { page--; rebuild(); });
		previous.active = page > 0;
		HgnButton next = button(layout.next(), layout.compact() ? ">" : "NEXT",
			() -> { page++; rebuild(); });
		next.active = page + 1 < layout.pages(filtered.size());
	}

	private HgnButton button(HgnRect bounds, String label, Runnable action) {
		return addRenderableWidget(HgnButton.dashboardCentered(bounds.x(), bounds.y(),
			bounds.width(), bounds.height(), Component.literal(label), false,
			ignored -> action.run()).referenceScale(1.0f));
	}

	private void select(String fileName) {
		selectedFile = fileName;
		selectedBox.setValue(fileName);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		HgnScreenBackdrop.render(this, graphics, mouseX, mouseY);
		HgnSurface.panel(graphics, layout.panel(), false);
		int textX = layout.panel().x() + (layout.compact() ? 7 : 13);
		int textWidth = layout.panel().width() - (layout.compact() ? 14 : 26);
		int iconSize = layout.compact() ? 12 : 22;
		HgnIcon.MODS.draw(graphics, textX, layout.panel().y() + (layout.compact() ? 4 : 7),
			iconSize, HgnPalette.CYAN);
		HgnTypography.fitted(graphics, font, "HGN / INSTALLED MODS", textX + iconSize + 5,
			layout.panel().y() + (layout.compact() ? 5 : 9), textWidth - iconSize - 5,
			layout.compact() ? 1.0f : 1.35f, HgnPalette.CYAN);
		String count = filtered.size() == snapshot.jars().size()
			? snapshot.jars().size() + " installed JAR files in this instance"
			: filtered.size() + " matching / " + snapshot.jars().size() + " installed JAR files";
		HgnTypography.fitted(graphics, font, count, textX,
			layout.panel().y() + (layout.compact() ? 16 : 27), textWidth,
			layout.compact() ? 0.72f : 0.9f, HgnPalette.mutedText());
		for (int row = 0; row < rowButtons.size(); row++) {
			String fileName = filtered.get(page * layout.rowsPerPage() + row).fileName();
			HgnRect bounds = layout.row(row);
			int badgeWidth = layout.compact() ? 24 : 34;
			boolean highlighted = fileName.equals(selectedFile)
				|| rowButtons.get(row).isHoveredOrFocused();
			HgnSurface.dashboardInset(graphics, bounds, highlighted);
			HgnTypography.fitted(graphics, font, HgnTypography.trim(font, fileName,
				bounds.width() - badgeWidth - 20), bounds.x() + 8,
				bounds.y() + (layout.compact() ? 2 : 7), bounds.width() - badgeWidth - 18,
				layout.compact() ? 0.8f : 1.0f,
				fileName.equals(selectedFile) ? HgnPalette.CYAN : HgnPalette.TEXT);
			HgnTypography.centered(graphics, font, "JAR", bounds.right() - badgeWidth / 2 - 3,
				bounds.y() + (layout.compact() ? 2 : 7), layout.compact() ? 0.66f : 0.8f,
				HgnPalette.CYAN);
		}
		if (filtered.isEmpty()) {
			String message = !snapshot.problem().isEmpty() ? snapshot.problem()
				: snapshot.jars().isEmpty() ? "No installed JAR files in this instance."
				: "No filenames match this search.";
			HgnTypography.fitted(graphics, font, message, layout.list().x() + 5,
				layout.list().y() + 8, layout.list().width() - 10,
				layout.compact() ? 0.83f : 1.0f, HgnPalette.mutedText());
		}
		HgnSurface.dashboardInset(graphics, layout.detail(), false);
		if (!layout.compact()) HgnTypography.fitted(graphics, font,
			"EXACT INSTALLED FILENAME / VIEW ONLY", layout.detail().x() + 6,
			layout.detail().y() + 3, layout.detail().width() - 12,
			0.85f, HgnPalette.CYAN);
		if (!layout.compact()) HgnTypography.fitted(graphics, font,
			"Metadata is not inferred. Choose the instance in HGN Launcher to add or change versions.",
			layout.detail().x() + 6, layout.detail().y() + 37,
			layout.detail().width() - 12, 0.7f, HgnPalette.mutedText());
		HgnTypography.centered(graphics, font,
			(page + 1) + " / " + layout.pages(filtered.size()),
			(layout.manage().right() + layout.previous().x()) / 2,
			layout.back().y() + (layout.compact() ? 4 : 7),
			layout.compact() ? 0.75f : 0.9f, HgnPalette.mutedText());
		super.render(graphics, mouseX, mouseY, partialTick);
	}

	@Override
	public void onClose() {
		minecraft.setScreen(parent);
	}
}
