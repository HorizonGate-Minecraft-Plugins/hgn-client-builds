package online.horizongate.hgn.screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import online.horizongate.hgn.HgnClient;
import online.horizongate.hgn.compat.HgnCompat;
import online.horizongate.hgn.compat.HgnDraw;
import online.horizongate.hgn.cosmetics.HgnCosmetics;
import online.horizongate.hgn.net.HgnMessages;
import online.horizongate.hgn.ui.HgnDashboardLayout;
import online.horizongate.hgn.ui.HgnIcon;
import online.horizongate.hgn.ui.HgnPalette;
import online.horizongate.hgn.ui.HgnRect;
import online.horizongate.hgn.ui.HgnReferenceShellLayout;
import online.horizongate.hgn.ui.HgnScreenBackdrop;
import online.horizongate.hgn.ui.HgnSurface;
import online.horizongate.hgn.ui.dashboard.HgnTypography;
import online.horizongate.hgn.ui.widget.HgnButton;

/** The three-panel gateway reference, with real client data and native widget inputs. */
public final class HgnDashboardScreen extends Screen {
	private static final String[] FEATURE_LABELS = {
		"PERFORMANCE", "ENHANCED HUD", "CUSTOMIZATION", "COSMETICS"
	};
	private static final String[][] FEATURE_DETAILS = {
		{"Fine-tune rendering", "for smoother gameplay."},
		{"Custom HUD elements", "for better awareness."},
		{"Fine-tune visuals and", "gameplay to your style."},
		{"Your skins, capes", "and equipped looks."}
	};
	private static final HgnIcon[] FEATURE_ICONS = {
		HgnIcon.PERFORMANCE, HgnIcon.HUD, HgnIcon.SETTINGS, HgnIcon.COSMETICS
	};
	private static final String[] COMPACT_LABELS = {
		"Singleplayer", "Multiplayer", "Servers", "Mods",
		"Cosmetics", "Settings", "Account", "Exit"
	};
	private static final String[] COMPACT_DETAILS = {
		"Your worlds", "Saved servers", "Official network", "Installed mods",
		"Your equipped look", "HGN and Minecraft options", "Open launcher account", "Close Minecraft"
	};
	private static final HgnIcon[] COMPACT_ICONS = {
		HgnIcon.WORLD, HgnIcon.MULTIPLAYER, HgnIcon.SERVERS, HgnIcon.MODS,
		HgnIcon.COSMETICS, HgnIcon.SETTINGS, HgnIcon.PROFILE, HgnIcon.EXIT
	};
	private HgnDashboardLayout layout;
	private HgnReferenceShellLayout shell;
	private online.horizongate.hgn.ui.HgnCompactDashboardLayout compactLayout;
	private HgnDashboardData.Snapshot snapshot = HgnDashboardData.Snapshot.empty();
	private boolean dataReady;
	private boolean dataLoading;
	private HgnRect rail, content, profile, welcome, accountCard, preview, credits, emptyServers;
	private boolean videoRuntimeSmokeOpened;
	private final HgnRect[] worlds = new HgnRect[3];
	private final HgnRect[] servers = new HgnRect[3];
	private final HgnRect[] features = new HgnRect[4];
	private final HgnButton[] featureButtons = new HgnButton[4];
	private final HgnButton[] compactButtons = new HgnButton[8];
	private final HgnButton[] worldButtons = new HgnButton[3];
	private final HgnButton[] serverButtons = new HgnButton[3];
	private HgnButton emptyServerButton;
	private HgnButton accountButton;

	public HgnDashboardScreen() {
		super(Component.literal("HGN Client"));
	}

	@Override
	protected void init() {
		HgnClient.ensureStarted();
		layout = HgnDashboardLayout.resolve(width, height);
		shell = new HgnReferenceShellLayout(layout);
		compactLayout = online.horizongate.hgn.ui.HgnCompactDashboardLayout.needed(width, height)
			? online.horizongate.hgn.ui.HgnCompactDashboardLayout.resolve(width, height) : null;
		rebuildDashboardWidgets();
		if (compactLayout == null) loadDashboardData();
	}

	private void loadDashboardData() {
		if (dataReady || dataLoading) return;
		dataLoading = true;
		HgnDashboardData.load(minecraft).whenComplete((loaded, failure) -> minecraft.execute(() -> {
			dataLoading = false;
			snapshot = failure == null && loaded != null
				? loaded : HgnDashboardData.Snapshot.empty();
			dataReady = minecraft.screen == this;
			if (minecraft.screen == this) rebuildDashboardWidgets();
		}));
	}

	@Override
	public void tick() {
		super.tick();
		if (!videoRuntimeSmokeOpened && HgnClient.videoRuntimeSmoke() && minecraft.screen == this) {
			videoRuntimeSmokeOpened = true;
			minecraft.setScreen(new OptionsScreen(this, minecraft.options));
		}
	}

	private void rebuildDashboardWidgets() {
		clearWidgets();
		if (compactLayout != null) {
			compactCommand(0, () -> minecraft.setScreen(new HgnSelectWorldScreen(this)));
			compactCommand(1, () -> minecraft.setScreen(new HgnSavedServersScreen(this)));
			compactCommand(2, () -> minecraft.setScreen(new HgnMultiplayerScreen(this)));
			compactCommand(3, () -> minecraft.setScreen(new HgnInstalledModsScreen(this)));
			compactCommand(4, () -> minecraft.setScreen(new HgnCosmeticsScreen(this)));
			compactCommand(5, () -> minecraft.setScreen(new HgnClientSettingsScreen(this)));
			compactCommand(6, () -> HgnCompat.openUrl("hgn://account?playerId=" + minecraft.getUser().getProfileId()));
			compactCommand(7, () -> HgnCompat.quit(minecraft));
			return;
		}
		rail = shell.rail();
		content = layout.rect(208, 198, 425, 250);
		profile = layout.rect(636, 116, 178, 332);
		welcome = shell.featuredNetwork();
		accountCard = layout.rect(648, 149, 156, 44);
		preview = layout.rect(648, 200, 156, 164);
		credits = layout.rect(648, 390, 156, 49);
		emptyServers = layout.rect(223, 286, 395, 44);
		for (int index = 0; index < 3; index++) {
			worlds[index] = layout.rect(223 + index * 132, 212, 125, 44);
			servers[index] = layout.rect(223 + index * 132, 286, 125, 44);
			worldButtons[index] = null;
			serverButtons[index] = null;
		}
		for (int index = 0; index < 4; index++) {
			features[index] = layout.rect(223 + index * 101, 360, 92, 78);
		}
		command(0, "PLAY", HgnIcon.PLAY, true,
			() -> minecraft.setScreen(new HgnMultiplayerScreen(this)));
		command(1, "SINGLEPLAYER", HgnIcon.WORLD, false,
			() -> minecraft.setScreen(new HgnSelectWorldScreen(this)));
		command(2, "MULTIPLAYER", HgnIcon.MULTIPLAYER, false,
			() -> minecraft.setScreen(new HgnSavedServersScreen(this)));
		command(3, "SERVERS", HgnIcon.SERVERS, false,
			() -> minecraft.setScreen(new HgnMultiplayerScreen(this)));
		command(4, "COSMETICS", HgnIcon.COSMETICS, false,
			() -> minecraft.setScreen(new HgnCosmeticsScreen(this)));
		command(5, "MODS", HgnIcon.MODS, false,
			() -> minecraft.setScreen(new HgnInstalledModsScreen(this)));
		command(6, "SETTINGS", HgnIcon.SETTINGS, false,
			() -> minecraft.setScreen(new HgnClientSettingsScreen(this)));
		command(7, "EXIT", HgnIcon.EXIT, false, () -> HgnCompat.quit(minecraft));
		addRenderableWidget(HgnButton.dashboardCentered(
			shell.featuredAction().x(), shell.featuredAction().y(),
			shell.featuredAction().width(), shell.featuredAction().height(),
			Component.literal("JOIN HORIZONGATE NETWORK"), true,
			ignored -> minecraft.setScreen(new HgnMultiplayerScreen(this)))
			.referenceScale(layout.scale()));
		for (int index = 0; index < Math.min(3, snapshot.worlds().size()); index++) {
			HgnDashboardData.RecentWorld world = snapshot.worlds().get(index);
			worldButtons[index] = target(worlds[index], "Open " + world.name(),
				() -> minecraft.createWorldOpenFlows().openWorld(world.id(),
					() -> minecraft.setScreen(this)));
		}
		emptyServerButton = null;
		if (snapshot.servers().isEmpty()) {
			emptyServerButton = target(emptyServers, "Add a favorite server",
				() -> minecraft.setScreen(new HgnMultiplayerScreen(this)));
		} else {
			for (int index = 0; index < 3; index++) {
				if (index < snapshot.servers().size()) {
					HgnDashboardData.SavedServer server = snapshot.servers().get(index);
					serverButtons[index] = target(servers[index], "Join " + server.name(),
						() -> HgnCompat.connect(this, minecraft, server.name(), server.address()));
				} else {
					serverButtons[index] = target(servers[index], "Add server",
						() -> minecraft.setScreen(new HgnMultiplayerScreen(this)));
				}
			}
		}
		for (int index = 0; index < features.length; index++) {
			int feature = index;
			featureButtons[index] = target(features[index], "Open " + FEATURE_LABELS[index],
				() -> openFeature(feature));
		}
		accountButton = target(accountCard, "Open HGN Launcher account",
			() -> HgnCompat.openUrl("hgn://account?playerId=" + minecraft.getUser().getProfileId()));
		HgnRect model = layout.rect(637, 205, 178, 123);
		addRenderableWidget(HgnCompat.profileWidget(minecraft,
			model.x(), model.y(), model.width(), model.height()));
	}

	private void compactCommand(int index, Runnable action) {
		HgnRect bounds = compactLayout.button(index);
		compactButtons[index] = target(bounds, COMPACT_LABELS[index], action);
	}

	private void command(int index, String label, HgnIcon icon, boolean primary, Runnable action) {
		HgnRect bounds = shell.destination(index);
		addRenderableWidget(HgnButton.dashboardCommand(bounds.x(), bounds.y(), bounds.width(),
			bounds.height(), Component.literal(label), icon, primary, button -> action.run())
			.referenceScale(layout.scale()));
	}

	private HgnButton target(HgnRect bounds, String label, Runnable action) {
		return addRenderableWidget(HgnButton.hitTarget(bounds.x(), bounds.y(), bounds.width(),
			bounds.height(), Component.literal(label), button -> action.run()));
	}

	private void openFeature(int feature) {
		switch (feature) {
			case 0 -> minecraft.setScreen(new OptionsScreen(this, minecraft.options));
			case 1, 2 -> minecraft.setScreen(new HgnClientSettingsScreen(this));
			case 3 -> minecraft.setScreen(new HgnCosmeticsScreen(this));
			default -> { }
		}
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		HgnScreenBackdrop.render(this, graphics, mouseX, mouseY);
		if (compactLayout != null) {
			renderCompact(graphics);
			super.render(graphics, mouseX, mouseY, partialTick);
			return;
		}
		HgnSurface.dashboardPanel(graphics, rail, false);
		HgnSurface.dashboardPanel(graphics, content, false);
		HgnSurface.dashboardPanel(graphics, profile, false);
		renderHeader(graphics);
		renderWelcome(graphics);
		renderWorlds(graphics);
		renderServers(graphics);
		renderFeatures(graphics);
		renderProfile(graphics);
		super.render(graphics, mouseX, mouseY, partialTick);
		centered(graphics, "DRAG TO ROTATE", 726, 348, 0.8f, HgnPalette.TEXT_MUTED);
	}

	private void renderHeader(GuiGraphics graphics) {
		HgnRect masthead = layout.rect(20, 12, 384, 69);
		HgnDraw.gradient(graphics, masthead.x(), masthead.y(), masthead.right(), masthead.bottom(),
			0xC4071119, 0xA0071119);
		HgnRect mark = shell.wordmark();
		HgnSurface.wordmark(graphics, mark.x(), mark.y(), mark.width(), mark.height(), false);
		fitted(graphics, "HORIZONGATE NETWORK", 108, 27, 284, 1.62f, HgnPalette.TEXT);
		text(graphics, "C L I E N T", 108, 47, 1.16f, HgnPalette.CYAN);
		fitted(graphics, "PLAY  /  EXPLORE  /  CUSTOMIZE  /  BELONG",
			108, 66, 260, 0.76f, HgnPalette.TEXT);
		HgnRect badge = shell.versionBadge();
		HgnSurface.dashboardInset(graphics, badge, false);
		HgnTypography.centered(graphics, font, "HGN " + HgnClient.minecraftVersion(),
			badge.centerX(), badge.y() + Math.max(4, (badge.height() - font.lineHeight) / 2),
			Math.max(0.75f, layout.scale() * 0.86f), HgnPalette.CYAN);
	}

	private void renderCompact(GuiGraphics graphics) {
		HgnRect panel = compactLayout.panel();
		int x = panel.x();
		int y = panel.y();
		int right = panel.right();
		int bottom = panel.bottom();
		HgnDraw.gradient(graphics, x + 6, y, right - 6, bottom,
			0xEE0B1922, 0xF2071119);
		HgnDraw.gradient(graphics, x, y + 6, x + 6, bottom - 6,
			0xEE0B1922, 0xF2071119);
		HgnDraw.gradient(graphics, right - 6, y + 6, right, bottom - 6,
			0xEE0B1922, 0xF2071119);
		HgnDraw.rect(graphics, x + 6, y, right - 6, y + 1, HgnPalette.EDGE_STRONG);
		HgnDraw.rect(graphics, x + 6, bottom - 1, right - 6, bottom, HgnPalette.EDGE_STRONG);
		HgnDraw.rect(graphics, x, y + 6, x + 1, bottom - 6, HgnPalette.EDGE_STRONG);
		HgnDraw.rect(graphics, right - 1, y + 6, right, bottom - 6, HgnPalette.EDGE_STRONG);
		HgnSurface.cornerAccent(graphics, panel, true);

		HgnRect header = compactLayout.header();
		HgnSurface.wordmark(graphics, header.x() + 2, header.y() + 2, 38, 20, false);
		HgnDraw.rect(graphics, header.x() + 48, header.y() + 2,
			header.x() + 49, header.y() + 23, HgnPalette.CYAN);
		HgnTypography.fitted(graphics, font, "HorizonGate Network",
			header.x() + 57, header.y() + 1, header.width() - 59, 1.05f, HgnPalette.CYAN);
		HgnTypography.text(graphics, font, "PLAY BEYOND",
			header.x() + 57, header.y() + 16, 0.72f, HgnPalette.mutedText());
		HgnSurface.separator(graphics, header.x(), header.bottom() + 1, header.width(), false);

		for (int index = 0; index < compactButtons.length; index++) {
			HgnRect card = compactLayout.button(index);
			boolean highlighted = index < 2 || hot(compactButtons[index]);
			HgnSurface.dashboardInset(graphics, card, highlighted);
			if (index < 2) HgnDraw.rect(graphics, card.x() + 1, card.y() + 5,
				card.x() + 2, card.bottom() - 5, HgnPalette.CYAN);
			int iconSize = Math.min(18, card.height() - 8);
			COMPACT_ICONS[index].draw(graphics, card.x() + 7,
				card.centerY() - iconSize / 2, iconSize, HgnPalette.CYAN_SOFT);
			int textX = card.x() + 31;
			int textWidth = card.width() - 38;
			int titleY = card.y() + Math.max(3, (card.height() - 19) / 2);
			HgnTypography.fitted(graphics, font, COMPACT_LABELS[index],
				textX, titleY, textWidth, 0.98f, HgnPalette.TEXT);
			HgnTypography.fitted(graphics, font, COMPACT_DETAILS[index],
				textX, titleY + 11, textWidth, 0.72f, HgnPalette.mutedText());
		}
		HgnRect footer = compactLayout.footer();
		HgnTypography.text(graphics, font, "HGN CLIENT", footer.x(), footer.y(),
			0.72f, HgnPalette.mutedText());
		HgnTypography.text(graphics, font, "PLAY BEYOND", footer.right() - 73,
			footer.y(), 0.72f, HgnPalette.CYAN);
	}

	private void renderWelcome(GuiGraphics graphics) {
		HgnSurface.dashboardInset(graphics, welcome, true);
		HgnRect scenery = layout.rect(209, 95, 423, 94);
		HgnDraw.textureRegionStretch(graphics, "textures/gui/hgn_gateway_twilight.png",
			scenery.x(), scenery.y(), scenery.width(), scenery.height(),
			0, 100, 1672, 377, 1672, 941);
		HgnDraw.rect(graphics, layout.x(211), layout.y(97), layout.x(454), layout.y(189), 0xD007141C);
		HgnSurface.cornerAccent(graphics, welcome, true);
		text(graphics, "OFFICIAL NETWORK", 228, 103, 0.76f, HgnPalette.CYAN);
		fitted(graphics, "HORIZONGATE NETWORK", 228, 115, 218, 1.35f, HgnPalette.TEXT);
		fitted(graphics, "Explore, build and belong across HGN worlds.",
			228, 139, 220, 0.9f, HgnPalette.TEXT_MUTED);
	}

	private void section(GuiGraphics graphics, HgnIcon icon, String label, int y, int count) {
		icon(graphics, icon, 224, y - 2, 12);
		text(graphics, label, 241, y, 0.92f, HgnPalette.TEXT_MUTED);
		if (count >= 0) text(graphics, Math.min(count, 3) + " / 3", 598, y, 0.86f, HgnPalette.TEXT_MUTED);
	}

	private void renderWorlds(GuiGraphics graphics) {
		section(graphics, HgnIcon.WORLD, "RECENT WORLDS", 200, snapshot.worlds().size());
		for (int index = 0; index < 3; index++) {
			HgnSurface.dashboardInset(graphics, worlds[index], hot(worldButtons[index]));
			int x = 223 + index * 132;
			if (index < snapshot.worlds().size()) {
				HgnDashboardData.RecentWorld world = snapshot.worlds().get(index);
				icon(graphics, HgnIcon.WORLD, x + 9, 223, 24);
				fitted(graphics, world.name(), x + 43, 225, 76, 0.9f, HgnPalette.TEXT);
				fitted(graphics, world.detail(), x + 43, 239, 76, 0.78f, HgnPalette.TEXT_MUTED);
			} else {
				dashed(graphics, x + 9, 220, 26, 28);
				fitted(graphics, dataReady ? "No recent worlds" : "Loading worlds…",
					x + 43, 227, 76, 0.9f, HgnPalette.TEXT_MUTED);
				text(graphics, "—", x + 43, 239, 0.9f, HgnPalette.TEXT_MUTED);
			}
		}
	}

	private void renderServers(GuiGraphics graphics) {
		section(graphics, HgnIcon.SERVERS, "FAVORITE SERVERS", 273, snapshot.servers().size());
		if (snapshot.servers().isEmpty()) {
			HgnSurface.dashboardInset(graphics, emptyServers, hot(emptyServerButton));
			dashed(graphics, 347, 294, 28, 28);
			centered(graphics, "+", 361, 299, 2.0f, HgnPalette.TEXT_MUTED);
			text(graphics, dataReady ? "No favorite servers" : "Loading servers…",
				384, 301, 0.92f, HgnPalette.TEXT_MUTED);
			text(graphics, "Add servers to see them here.", 384, 314, 0.83f, HgnPalette.TEXT_MUTED);
			return;
		}
		for (int index = 0; index < 3; index++) {
			HgnSurface.dashboardInset(graphics, servers[index], hot(serverButtons[index]));
			int x = 223 + index * 132;
			if (index < snapshot.servers().size()) {
				HgnDashboardData.SavedServer server = snapshot.servers().get(index);
				icon(graphics, HgnIcon.MULTIPLAYER, x + 9, 297, 24);
				fitted(graphics, server.name(), x + 42, 299, 77, 0.9f, HgnPalette.TEXT);
				fitted(graphics, server.address(), x + 42, 313, 77, 0.75f, HgnPalette.TEXT_MUTED);
			} else {
				centered(graphics, "+  ADD SERVER", x + 62, 304, 0.9f, HgnPalette.TEXT_MUTED);
			}
		}
	}

	private void renderFeatures(GuiGraphics graphics) {
		section(graphics, HgnIcon.EFFECTS, "CLIENT FEATURES", 346, -1);
		for (int index = 0; index < 4; index++) {
			HgnRect card = features[index];
			HgnSurface.dashboardInset(graphics, card, hot(featureButtons[index]));
			HgnSurface.cornerAccent(graphics, card, false);
			int center = 269 + index * 101;
			icon(graphics, FEATURE_ICONS[index], center - 13, 368, 26);
			centered(graphics, FEATURE_LABELS[index], center, 397, 0.83f, HgnPalette.TEXT);
			centered(graphics, FEATURE_DETAILS[index][0], center, 410, 0.8f, HgnPalette.TEXT_MUTED);
			centered(graphics, FEATURE_DETAILS[index][1], center, 420, 0.8f, HgnPalette.TEXT_MUTED);
		}
	}

	private void renderProfile(GuiGraphics graphics) {
		icon(graphics, HgnIcon.PROFILE, 649, 130, 12);
		text(graphics, "PROFILE", 667, 133, 0.94f, HgnPalette.TEXT);
		HgnSurface.dashboardInset(graphics, accountCard, hot(accountButton));
		HgnSurface.dashboardInset(graphics, preview, false);
		HgnSurface.dashboardInset(graphics, credits, false);
		texture(graphics, "profile_platform.png", 678, 312, 96, 36, 256, 96);
		HgnCosmetics.Profile account = HgnMessages.cosmetics().profile();
		HgnCosmetics.ConnectionState connection = HgnCosmetics.connectionState();
		String name = minecraft.getUser().getName();
		fitted(graphics, name, 662, 158, 106, 1.0f, HgnPalette.TEXT);
		fitted(graphics, connection.compactLabel(), 662, 170, 108, 0.88f, HgnPalette.TEXT_MUTED);
		fitted(graphics, connection.dashboardDescription(), 662, 180, 108, 0.88f, HgnPalette.TEXT_MUTED);
		icon(graphics, HgnIcon.LINK, 777, 164, 15);
		icon(graphics, HgnIcon.HGN_GOLDEN_TOKENS, 649, 373, 13);
		text(graphics, account.legacyCurrency() ? "ACCOUNT BALANCES" : "ACCOUNT TOKENS",
			667, 377, 0.94f, HgnPalette.TEXT_MUTED);
		icon(graphics, HgnIcon.HGN_GOLDEN_TOKENS, 658, 400, 27);
		if (account.launcherLinked()) {
			if (account.legacyCurrency()) {
				fitted(graphics, account.legacyAccountCredits(), 691, 400, 102, 1.08f, HgnPalette.TEXT);
				text(graphics, "Account Credits", 691, 413, 0.83f, HgnPalette.TEXT_MUTED);
				fitted(graphics, account.legacyCosmeticCoins() + " Cosmetic Coins",
					691, 423, 103, 0.8f, HgnPalette.TEXT_MUTED);
			} else {
				fitted(graphics, account.hgnGoldenTokens(), 691, 400, 102, 1.08f, HgnPalette.TEXT);
				text(graphics, "HGN Golden Tokens", 691, 413, 0.83f, HgnPalette.TEXT_MUTED);
				fitted(graphics, account.hgnTokens() + " HGN Tokens", 691, 423, 103, 0.8f, HgnPalette.TEXT_MUTED);
			}
		} else {
			fitted(graphics, connection.compactLabel(), 691, 399, 102, 1.0f, HgnPalette.TEXT);
			fitted(graphics, connection.dashboardDescription(), 691, 412, 102, 0.83f, HgnPalette.TEXT_MUTED);
		}
	}

	private void text(GuiGraphics graphics, String text, int x, int y, float emphasis, int color) {
		HgnTypography.text(graphics, font, text, layout.x(x), layout.y(y), layout.scale() * emphasis, color);
	}

	private void centered(GuiGraphics graphics, String text, int x, int y, float emphasis, int color) {
		HgnTypography.centered(graphics, font, text, layout.x(x), layout.y(y), layout.scale() * emphasis, color);
	}

	private void fitted(GuiGraphics graphics, String text, int x, int y, int width, float emphasis, int color) {
		String visible = HgnTypography.trim(font, text, Math.round(width / emphasis));
		text(graphics, visible, x, y, emphasis, color);
	}

	private void icon(GuiGraphics graphics, HgnIcon icon, int x, int y, int size) {
		icon.draw(graphics, layout.x(x), layout.y(y), layout.size(size), HgnPalette.CYAN_SOFT);
	}

	private void texture(GuiGraphics graphics, String path, int x, int y, int width, int height,
		int sourceWidth, int sourceHeight) {
		HgnDraw.textureStretch(graphics, "textures/gui/" + path, layout.x(x), layout.y(y),
			layout.size(width), layout.size(height), sourceWidth, sourceHeight);
	}

	private void dashed(GuiGraphics graphics, int x, int y, int width, int height) {
		int color = 0xA8788790;
		for (int offset = 0; offset < width; offset += 4) {
			HgnDraw.rect(graphics, layout.x(x + offset), layout.y(y),
				layout.x(x + Math.min(offset + 2, width)), layout.y(y) + 1, color);
			HgnDraw.rect(graphics, layout.x(x + offset), layout.y(y + height),
				layout.x(x + Math.min(offset + 2, width)), layout.y(y + height) + 1, color);
		}
		for (int offset = 0; offset < height; offset += 4) {
			HgnDraw.rect(graphics, layout.x(x), layout.y(y + offset), layout.x(x) + 1,
				layout.y(y + Math.min(offset + 2, height)), color);
			HgnDraw.rect(graphics, layout.x(x + width), layout.y(y + offset), layout.x(x + width) + 1,
				layout.y(y + Math.min(offset + 2, height)), color);
		}
	}

	private static boolean hot(AbstractWidget widget) {
		return widget != null && widget.isHoveredOrFocused();
	}

	@Override
	public void removed() {
		dataReady = false;
		super.removed();
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
	}
}
