package online.horizongate.hgn.ui;

/** Native-pixel Cosmetics geometry; small windows switch details into a separate pane. */
public record HgnCosmeticsLayout(boolean compact, HgnRect rail, HgnRect catalogue,
	HgnRect profile, HgnRect featured, HgnRect search, HgnRect rarity,
	HgnRect sort, HgnRect owned, HgnRect cards, HgnRect previous,
	HgnRect next, HgnRect preview, HgnRect selection, HgnRect equipped,
	HgnRect wallet, HgnRect back, HgnRect categoryPager,
	int categoryPageSize, int columns, int rows) {

	public static HgnCosmeticsLayout resolve(int width, int height) {
		int margin = clamp(Math.min(width, height) / 52, 4, 10);
		int canvasWidth = Math.min(Math.max(0, width - margin * 2), 1000);
		int canvasHeight = Math.min(Math.max(0, height - margin * 2), 600);
		int left = (width - canvasWidth) / 2;
		int top = (height - canvasHeight) / 2;
		boolean compact = width < 500 || height < 260;
		int gap = compact ? 4 : 6;
		int railWidth = compact ? clamp(canvasWidth * 21 / 100, 62, 80)
			: clamp(canvasWidth * 17 / 100, 88, 170);
		int profileWidth = compact ? 0 : clamp(canvasWidth * 25 / 100, 124, 250);
		HgnRect rail = new HgnRect(left, top, railWidth, canvasHeight);
		int contentX = rail.right() + gap;
		int contentWidth = Math.max(1, canvasWidth - railWidth - gap
			- (compact ? 0 : profileWidth + gap));
		HgnRect catalogue = new HgnRect(contentX, top, contentWidth, canvasHeight);
		HgnRect profile = compact
			? new HgnRect(contentX, top, contentWidth, canvasHeight)
			: new HgnRect(catalogue.right() + gap, top, profileWidth, canvasHeight);
		int featuredHeight = compact ? 32 : canvasHeight < 390 ? 54 : 70;
		HgnRect featured = new HgnRect(catalogue.x() + 5, top + 20,
			catalogue.width() - 10, featuredHeight);
		int controlsY = featured.bottom() + 4;
		HgnRect search;
		HgnRect rarity;
		HgnRect sort;
		HgnRect owned;
		int controlsBottom;
		if (compact) {
			search = new HgnRect(catalogue.x() + 5, controlsY,
				catalogue.width() - 10, 13);
			int filterY = search.bottom() + 2;
			int filterWidth = (catalogue.width() - 16) / 3;
			rarity = new HgnRect(catalogue.x() + 5, filterY, filterWidth, 14);
			sort = new HgnRect(rarity.right() + 3, filterY, filterWidth, 14);
			owned = new HgnRect(sort.right() + 3, filterY,
				catalogue.right() - 5 - sort.right() - 3, 14);
			controlsBottom = owned.bottom();
		} else {
			int innerWidth = catalogue.width() - 10;
			int searchWidth = Math.max(90, innerWidth * 37 / 100);
			int filterWidth = (innerWidth - searchWidth - 9) / 3;
			search = new HgnRect(catalogue.x() + 5, controlsY, searchWidth, 18);
			rarity = new HgnRect(search.right() + 3, controlsY, filterWidth, 18);
			sort = new HgnRect(rarity.right() + 3, controlsY, filterWidth, 18);
			owned = new HgnRect(sort.right() + 3, controlsY,
				catalogue.right() - 5 - sort.right() - 3, 18);
			controlsBottom = search.bottom();
		}
		int footerY = catalogue.bottom() - 19;
		HgnRect cards = new HgnRect(catalogue.x() + 5, controlsBottom + 5,
			catalogue.width() - 10, Math.max(1, footerY - controlsBottom - 9));
		int columns = clamp(cards.width() / 90, 3, 5);
		int rows = compact ? 1 : clamp(cards.height() / 92, 1, 2);
		int pagingWidth = compact ? 23 : 29;
		HgnRect previous = new HgnRect(catalogue.centerX() - pagingWidth - 23,
			footerY + 1, pagingWidth, 14);
		HgnRect next = new HgnRect(catalogue.centerX() + 23,
			footerY + 1, pagingWidth, 14);
		HgnRect preview;
		HgnRect selection;
		HgnRect equipped;
		HgnRect wallet;
		if (compact) {
			int previewWidth = clamp((profile.width() - 14) * 40 / 100, 80, 124);
			int previewHeight = Math.min(83, profile.height() - 80);
			preview = new HgnRect(profile.x() + 5, profile.y() + 20,
				previewWidth, previewHeight);
			selection = new HgnRect(preview.right() + 4, preview.y(),
				profile.right() - preview.right() - 9, previewHeight);
			wallet = new HgnRect(profile.x() + 5, profile.bottom() - 35,
				profile.width() - 10, 30);
			equipped = new HgnRect(profile.x() + 5, preview.bottom() + 4,
				profile.width() - 10, Math.max(1, wallet.y() - preview.bottom() - 8));
		} else {
			int previewHeight = Math.min(160, Math.max(89, profile.height() * 32 / 100));
			preview = new HgnRect(profile.x() + 5, profile.y() + 20,
				profile.width() - 10, previewHeight);
			selection = new HgnRect(profile.x() + 5, preview.bottom() + 4,
				profile.width() - 10, 68);
			wallet = new HgnRect(profile.x() + 5, profile.bottom() - 72,
				profile.width() - 10, 67);
			equipped = new HgnRect(profile.x() + 5, selection.bottom() + 4,
				profile.width() - 10, Math.max(1, wallet.y() - selection.bottom() - 8));
		}
		int backHeight = compact ? 14 : 18;
		HgnRect back = new HgnRect(rail.x() + 5, rail.bottom() - backHeight - 5,
			rail.width() - 10, backHeight);
		HgnRect categoryPager = compact
			? new HgnRect(rail.x() + 5, back.y() - 17, rail.width() - 10, 14)
			: new HgnRect(0, 0, 0, 0);
		return new HgnCosmeticsLayout(compact, rail, catalogue, profile, featured,
			search, rarity, sort, owned, cards, previous, next, preview, selection,
			equipped, wallet, back, categoryPager, compact ? 6 : 11, columns, rows);
	}

	public HgnRect category(int visibleIndex) {
		int firstY = rail.y() + (compact ? 26 : 42);
		int gap = 2;
		int availableBottom = compact ? categoryPager.y() - 3 : back.y() - 4;
		int rowHeight = Math.max(10,
			Math.min(compact ? 15 : 23,
				(availableBottom - firstY - gap * (categoryPageSize - 1)) / categoryPageSize));
		return new HgnRect(rail.x() + 5, firstY + visibleIndex * (rowHeight + gap),
			rail.width() - 10, rowHeight);
	}

	public HgnRect card(int index) {
		int gap = compact ? 3 : 5;
		int cardWidth = (cards.width() - gap * (columns - 1)) / columns;
		int cardHeight = (cards.height() - gap * (rows - 1)) / rows;
		return new HgnRect(cards.x() + index % columns * (cardWidth + gap),
			cards.y() + index / columns * (cardHeight + gap), cardWidth, cardHeight);
	}

	public HgnRect emptyState() {
		return cards.inset(Math.min(8, Math.min(cards.width(), cards.height()) / 8));
	}

	public static float walletTextScale(float preferredScale, int availableWidth, int textWidth) {
		return Math.min(preferredScale, Math.max(1, availableWidth) / (float) Math.max(1, textWidth));
	}

	private static int clamp(int value, int minimum, int maximum) {
		return Math.max(minimum, Math.min(maximum, value));
	}
}
