package online.horizongate.hgn.net;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import online.horizongate.hgn.compat.HgnCompat;

import java.nio.charset.StandardCharsets;
import java.util.function.Function;

/**
 * The {@code hgn:core} and {@code hgn:vinksmp} payload types.
 * These use only vanilla networking classes, so the same definitions are
 * registered by every loader adapter. The identifier type was renamed in
 * 1.21.11, so ids are built through the compat shim and never named here.
 */
public final class HgnPayloads {
	private HgnPayloads() {
	}

	public record Core(String json) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<Core> TYPE =
			new CustomPacketPayload.Type<>(HgnCompat.id("hgn", "core"));
		public static final StreamCodec<RegistryFriendlyByteBuf, Core> CODEC = jsonCodec(Core::new, Core::json);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	public record Vink(String json) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<Vink> TYPE =
			new CustomPacketPayload.Type<>(HgnCompat.id("hgn", "vinksmp"));
		public static final StreamCodec<RegistryFriendlyByteBuf, Vink> CODEC = jsonCodec(Vink::new, Vink::json);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	private static <T extends CustomPacketPayload> StreamCodec<RegistryFriendlyByteBuf, T> jsonCodec(
		Function<String, T> factory, Function<T, String> getter) {
		return StreamCodec.of(
			(buf, value) -> buf.writeBytes(getter.apply(value).getBytes(StandardCharsets.UTF_8)),
			buf -> {
				byte[] bytes = new byte[buf.readableBytes()];
				buf.readBytes(bytes);
				return factory.apply(new String(bytes, StandardCharsets.UTF_8));
			});
	}
}
