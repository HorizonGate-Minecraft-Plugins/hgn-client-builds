package online.horizongate.hgn.ui;

/** Native-size saved/LAN controls for viewports too small for the reference frame. */
public final class HgnSavedServersLayout {
	private HgnSavedServersLayout() {
	}

	public static HgnRect header(int width) {
		return new HgnRect(8, 5, width - 16, 28);
	}

	public static HgnRect back() {
		return new HgnRect(12, 8, 52, 20);
	}

	public static HgnRect search(int width) {
		return new HgnRect(70, 8, width - 150, 20);
	}

	public static HgnRect refresh(int width) {
		return new HgnRect(width - 76, 8, 68, 20);
	}

	public static HgnRect tab(int width, int index) {
		if (index < 0 || index > 3) throw new IllegalArgumentException("Invalid server tab");
		int cellWidth = (width - 28) / 4;
		int x = 8 + index * (cellWidth + 4);
		return new HgnRect(x, 37, index == 3 ? width - 8 - x : cellWidth, 23);
	}

	public static HgnRect content(int width, int height) {
		return new HgnRect(8, 65, width - 16, height - 72);
	}

	public static HgnRect row(int width, int height, int index) {
		if (index < 0 || index > 1) throw new IllegalArgumentException("Invalid saved-server row");
		int rowHeight = Math.min(46, Math.max(30, (height - 118) / 2));
		return new HgnRect(12, 69 + index * (rowHeight + 4), width - 24, rowHeight);
	}

	public static HgnRect previous(int height) {
		return new HgnRect(12, height - 31, 42, 24);
	}

	public static HgnRect next(int height) {
		return new HgnRect(58, height - 31, 42, 24);
	}

	public static HgnRect edit(int height) {
		return new HgnRect(104, height - 31, 46, 24);
	}

	public static HgnRect delete(int height) {
		return new HgnRect(154, height - 31, 84, 24);
	}

	public static HgnRect join(int width, int height) {
		return new HgnRect(242, height - 31, width - 254, 24);
	}
}
