package online.horizongate.hgn.ui;

/** Native-pixel, paged geometry for the read-only installed-mods destination. */
public record HgnInstalledModsLayout(boolean compact, HgnRect panel, HgnRect search,
	HgnRect list, HgnRect detail, HgnRect back, HgnRect refresh, HgnRect manage,
	HgnRect previous, HgnRect next, int rowHeight, int rowGap, int rowsPerPage) {
	public static HgnInstalledModsLayout resolve(int width, int height) {
		int margin = clamp(Math.min(width, height) / 45, 4, 10);
		int panelWidth = Math.min(Math.max(0, width - margin * 2), 900);
		int panelHeight = Math.min(Math.max(0, height - margin * 2), 560);
		HgnRect panel = new HgnRect((width - panelWidth) / 2,
			(height - panelHeight) / 2, panelWidth, panelHeight);
		boolean compact = width < 500 || height < 260;
		int inset = compact ? 5 : 10;
		int innerX = panel.x() + inset;
		int innerWidth = Math.max(1, panel.width() - inset * 2);
		int searchY = panel.y() + (compact ? 25 : 40);
		HgnRect search = new HgnRect(innerX, searchY, innerWidth, compact ? 15 : 21);
		int footerHeight = compact ? 15 : 22;
		int footerY = panel.bottom() - inset - footerHeight;
		HgnRect detail = new HgnRect(innerX, footerY - (compact ? 27 : 50),
			innerWidth, compact ? 23 : 45);
		int listY = search.bottom() + (compact ? 4 : 8);
		HgnRect list = new HgnRect(innerX, listY, innerWidth,
			Math.max(1, detail.y() - listY - (compact ? 4 : 8)));
		int rowGap = compact ? 2 : 3;
		int preferredRow = compact ? 15 : 24;
		int rows = Math.max(1, (list.height() + rowGap) / (preferredRow + rowGap));
		int rowHeight = Math.max(1, Math.min(preferredRow,
			(list.height() - rowGap * (rows - 1)) / rows));
		int actionWidth = compact ? 38 : 70;
		HgnRect back = new HgnRect(innerX, footerY, actionWidth, footerHeight);
		HgnRect refresh = new HgnRect(back.right() + 4, footerY, actionWidth, footerHeight);
		HgnRect manage = new HgnRect(refresh.right() + 4, footerY,
			compact ? 67 : 140, footerHeight);
		int pageWidth = compact ? 28 : 62;
		HgnRect next = new HgnRect(innerX + innerWidth - pageWidth, footerY,
			pageWidth, footerHeight);
		HgnRect previous = new HgnRect(next.x() - pageWidth - 4, footerY,
			pageWidth, footerHeight);
		return new HgnInstalledModsLayout(compact, panel, search, list, detail,
			back, refresh, manage, previous, next, rowHeight, rowGap, rows);
	}

	public HgnRect row(int index) {
		return new HgnRect(list.x(), list.y() + index * (rowHeight + rowGap),
			list.width(), rowHeight);
	}

	public int pages(int itemCount) {
		return Math.max(1, (Math.max(0, itemCount) + rowsPerPage - 1) / rowsPerPage);
	}

	private static int clamp(int value, int minimum, int maximum) {
		return Math.max(minimum, Math.min(maximum, value));
	}
}
