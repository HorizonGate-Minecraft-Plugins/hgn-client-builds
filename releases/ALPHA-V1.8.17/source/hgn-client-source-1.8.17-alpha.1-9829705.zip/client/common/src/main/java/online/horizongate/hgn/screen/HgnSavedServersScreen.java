package online.horizongate.hgn.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.multiplayer.ServerStatusPinger;
import net.minecraft.client.server.LanServerDetection;
import net.minecraft.network.chat.Component;
import online.horizongate.hgn.compat.HgnCompat;
import online.horizongate.hgn.ui.HgnDashboardLayout;
import online.horizongate.hgn.ui.HgnMultiplayerLayout;
import online.horizongate.hgn.ui.HgnPalette;
import online.horizongate.hgn.ui.HgnRect;
import online.horizongate.hgn.ui.HgnSavedServersLayout;
import online.horizongate.hgn.ui.HgnScreenBackdrop;
import online.horizongate.hgn.ui.HgnServerPopulation;
import online.horizongate.hgn.ui.HgnSurface;
import online.horizongate.hgn.ui.dashboard.HgnTypography;
import online.horizongate.hgn.ui.widget.HgnButton;

/** HGN saved-server and LAN browser backed by Minecraft's own server file and discovery. */
public final class HgnSavedServersScreen extends Screen {
	private final Screen parent;
	private final List<ServerData> entries = new ArrayList<>();
	private final java.util.Map<ServerData, Long> queried = new java.util.IdentityHashMap<>();
	private ServerList saved;
	private ServerStatusPinger pinger;
	private ExecutorService executor;
	private LanServerDetection.LanServerList lanList;
	private LanServerDetection.LanServerDetector detector;
	private HgnDashboardLayout frame;
	private boolean lan;
	private boolean compact;
	private int page;
	private String searchQuery = "";
	private EditBox searchBox;
	private ServerData selected;
	private final online.horizongate.hgn.ui.HgnDoubleClick serverClicks = new online.horizongate.hgn.ui.HgnDoubleClick();
	private long refreshStarted;
	private volatile long generation;
	private boolean confirmDelete;
	private String notice = "";

	public HgnSavedServersScreen(Screen parent) {
		this(parent, false);
	}

	public HgnSavedServersScreen(Screen parent, boolean lan) {
		super(Component.literal("HGN Servers"));
		this.parent = parent;
		this.lan = lan;
	}

	@Override
	protected void init() {
		frame = HgnDashboardLayout.resolve(width, height);
		compact = HgnMultiplayerLayout.compact(width, height);
		if (pinger == null) refresh();
		else rebuild();
	}

	private void refresh() {
		stop();
		entries.clear();
		queried.clear();
		selected = null;
		serverClicks.reset();
		confirmDelete = false;
		notice = "";
		refreshStarted = System.nanoTime();
		pinger = new ServerStatusPinger();
		executor = Executors.newFixedThreadPool(3, task -> {
			Thread thread = new Thread(task, "HGN saved server status");
			thread.setDaemon(true);
			return thread;
		});
		if (lan) {
			lanList = new LanServerDetection.LanServerList();
			try {
				detector = new LanServerDetection.LanServerDetector(lanList);
				detector.start();
			} catch (java.io.IOException failure) {
				notice = "LAN discovery unavailable. Use Direct connect.";
			}
		} else {
			saved = new ServerList(minecraft);
			saved.load();
			for (int index = 0; index < saved.size(); index++) entries.add(saved.get(index));
		}
		page = Math.min(page, Math.max(0, (filteredEntries().size() - 1) / pageSize()));
		pingPage();
		rebuild();
	}

	private int pageSize() { return compact ? 2 : 5; }

	private List<ServerData> filteredEntries() {
		List<ServerData> matches = new ArrayList<>();
		for (ServerData data : entries) {
			if (HgnMultiplayerLayout.matches(searchQuery, data.name, data.ip,
				data.motd == null ? null : data.motd.getString())) matches.add(data);
		}
		return matches;
	}

	private void pingPage() {
		long activeGeneration = generation;
		ServerStatusPinger activePinger = pinger;
		List<ServerData> visible = filteredEntries();
		for (int index = page * pageSize(); index < Math.min(visible.size(), (page + 1) * pageSize()); index++) {
			ServerData data = visible.get(index);
			if (queried.containsKey(data)) continue;
			queried.put(data, System.nanoTime());
			data.ping = -2;
			executor.execute(() -> {
				try {
					if (generation == activeGeneration) HgnCompat.pingServer(activePinger, data, () -> {}, () -> {});
				} finally {
					if (generation != activeGeneration) activePinger.removeAll();
				}
			});
		}
	}

	private void rebuild() {
		clearWidgets();
		if (compact) {
			rebuildCompact();
			return;
		}
		button(32, 85, 154, 28, "Saved servers", !lan, () -> switchMode(false));
		button(195, 85, 154, 28, "LAN games", lan, () -> switchMode(true));
		searchBox = addSearch(frame.rect(360, 85, 251, 28));
		button(620, 85, 178, 28, "Refresh", false, () -> {
			if (System.nanoTime() - refreshStarted > 2_000_000_000L) refresh();
		});
		List<ServerData> visible = filteredEntries();
		for (int index = page * 5; index < Math.min(visible.size(), page * 5 + 5); index++) {
			ServerData data = visible.get(index);
			var rect = frame.rect(32, 127 + (index % 5) * 46, 504, 40);
			addRenderableWidget(HgnButton.hitTarget(rect.x(), rect.y(), rect.width(), rect.height(),
				Component.literal("Select " + data.name), ignored -> select(data)));
		}
		button(555, 275, 241, 30, "Join server", true, this::join).active = selected != null;
		button(555, 314, 116, 27, "Edit", false, () -> edit(selected)).active = selected != null && !lan;
		button(679, 314, 117, 27, confirmDelete ? "Confirm delete" : "Delete", false,
			this::deleteSelected).active = selected != null && !lan;
		button(32, 365, 94, 24, "Previous", false, () -> changePage(-1)).active = page > 0;
		button(441, 365, 95, 24, "Next", false, () -> changePage(1)).active = (page + 1) * 5 < visible.size();
		button(32, 404, 177, 29, "Back", false, this::onClose);
		button(225, 404, 177, 29, "Add server", false, () -> edit(null));
		button(418, 404, 177, 29, "Direct connect", false,
			() -> minecraft.setScreen(new HgnServerEditorScreen(this, null, null, true)));
	}

	private void rebuildCompact() {
		compactButton(HgnSavedServersLayout.back(), "Back", false, this::onClose);
		searchBox = addSearch(HgnSavedServersLayout.search(width));
		compactButton(HgnSavedServersLayout.refresh(width), "Refresh", false, () -> {
			if (System.nanoTime() - refreshStarted > 2_000_000_000L) refresh();
		});
		compactButton(HgnSavedServersLayout.tab(width, 0), "Saved", !lan, () -> switchMode(false));
		compactButton(HgnSavedServersLayout.tab(width, 1), "LAN", lan, () -> switchMode(true));
		compactButton(HgnSavedServersLayout.tab(width, 2), "Add", false, () -> edit(null));
		compactButton(HgnSavedServersLayout.tab(width, 3), "Direct", false,
			() -> minecraft.setScreen(new HgnServerEditorScreen(this, null, null, true)));
		List<ServerData> visible = filteredEntries();
		for (int index = page * 2; index < Math.min(visible.size(), page * 2 + 2); index++) {
			ServerData data = visible.get(index);
			HgnRect row = HgnSavedServersLayout.row(width, height, index % 2);
			addRenderableWidget(HgnButton.hitTarget(row.x(), row.y(), row.width(), row.height(),
				Component.literal("Select " + data.name), ignored -> select(data)));
		}
		compactButton(HgnSavedServersLayout.previous(height), "Prev", false,
			() -> changePage(-1)).active = page > 0;
		compactButton(HgnSavedServersLayout.next(height), "Next", false,
			() -> changePage(1)).active = (page + 1) * 2 < visible.size();
		compactButton(HgnSavedServersLayout.edit(height), "Edit", false,
			() -> edit(selected)).active = selected != null && !lan;
		compactButton(HgnSavedServersLayout.delete(height),
			confirmDelete ? "Confirm delete" : "Delete", false,
			this::deleteSelected).active = selected != null && !lan;
		compactButton(HgnSavedServersLayout.join(width, height), "Join server", true,
			this::join).active = selected != null;
	}

	private EditBox addSearch(HgnRect bounds) {
		EditBox box = new EditBox(font, bounds.x(), bounds.y(), bounds.width(), bounds.height(),
			Component.literal("Search saved or LAN servers"));
		box.setMaxLength(100);
		box.setValue(searchQuery);
		box.setResponder(value -> {
			searchQuery = value;
			page = 0;
			int selectedIndex = filteredEntries().indexOf(selected);
			if (selectedIndex < 0 || selectedIndex >= pageSize()) selected = null;
			confirmDelete = false;
			serverClicks.reset();
			pingPage();
			rebuild();
			if (searchBox != null) setInitialFocus(searchBox);
		});
		return addRenderableWidget(box);
	}

	private HgnButton compactButton(HgnRect bounds, String label, boolean primary, Runnable action) {
		return addRenderableWidget(HgnButton.dashboardCentered(bounds.x(), bounds.y(), bounds.width(),
			bounds.height(), Component.literal(label), primary, ignored -> action.run()).referenceScale(1f));
	}

	private void switchMode(boolean value) {
		lan = value;
		page = 0;
		refresh();
	}

	private void changePage(int delta) {
		page += delta;
		selected = null;
		serverClicks.reset();
		confirmDelete = false;
		pingPage();
		rebuild();
	}

	private void edit(ServerData data) {
		minecraft.setScreen(new HgnServerEditorScreen(this, saved, data, false));
	}

	private void deleteSelected() {
		if (selected == null || lan || saved == null) return;
		if (!confirmDelete) { confirmDelete = true; rebuild(); return; }
		saved.remove(selected);
		saved.save();
		refresh();
	}

	private void select(ServerData data) {
		boolean doubleClick = serverClicks.activate(data, System.nanoTime());
		selected = data;
		confirmDelete = false;
		if (doubleClick) join();
		else rebuild();
	}

	private void join() {
		if (selected != null) HgnCompat.connect(this, minecraft, selected);
	}

	@Override
	public void tick() {
		if (pinger != null) pinger.tick();
		if (lanList != null) {
			var discovered = lanList.takeDirtyServers();
			if (discovered != null) {
				for (var server : discovered) {
					if (entries.stream().noneMatch(data -> data.ip.equals(server.getAddress()))) {
						entries.add(new ServerData(server.getMotd(), server.getAddress(), ServerData.Type.LAN));
					}
				}
				pingPage();
				rebuild();
			}
		}
	}

	private void stop() {
		generation++;
		if (detector != null) { detector.interrupt(); detector = null; }
		lanList = null;
		if (executor != null) { executor.shutdownNow(); executor = null; }
		if (pinger != null) { pinger.removeAll(); pinger = null; }
	}

	@Override
	public void removed() { serverClicks.reset(); stop(); }

	@Override
	public void onClose() { minecraft.setScreen(parent); }

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		HgnScreenBackdrop.render(this, graphics, mouseX, mouseY);
		if (compact) {
			renderCompact(graphics, mouseX, mouseY);
			super.render(graphics, mouseX, mouseY, partialTick);
			return;
		}
		HgnSurface.panel(graphics, frame.rect(18, 34, 798, 408), false);
		text(graphics, "HGN / SERVER BROWSER", 33, 52, 1.25f, HgnPalette.CYAN);
		text(graphics, lan ? "Local network games" : "Your saved destinations", 551, 55, 0.9f, HgnPalette.TEXT);
		List<ServerData> visible = filteredEntries();
		for (int index = page * 5; index < Math.min(visible.size(), page * 5 + 5); index++) {
			ServerData data = visible.get(index);
			int y = 127 + (index % 5) * 46;
			HgnRect row = frame.rect(32, y, 504, 40);
			HgnSurface.panel(graphics, row, data == selected || row.contains(mouseX, mouseY));
			fit(graphics, data.name, 44, y + 6, 299, 0.95f, HgnPalette.TEXT);
			fit(graphics, data.motd == null ? data.ip : data.motd.getString(), 44, y + 23, 325, 0.69f, HgnPalette.TEXT_MUTED);
			fit(graphics, status(data), 375, y + 7, 150, 0.7f, HgnPalette.CYAN);
			fit(graphics, players(data), 375, y + 23, 150, 0.7f, HgnPalette.TEXT_MUTED);
		}
		if (visible.isEmpty()) text(graphics, !searchQuery.isBlank() ? "No matching servers. Try another search."
			: lan ? "Searching for LAN games..." : "No saved servers. Add one below.",
			51, 168, 0.92f, HgnPalette.TEXT_MUTED);
		HgnSurface.panel(graphics, frame.rect(547, 127, 253, 224), false);
		text(graphics, "CONNECTION DETAILS", 559, 141, 0.83f, HgnPalette.CYAN);
		fit(graphics, selected == null ? "Select a server" : selected.name, 559, 166, 229, 1f, HgnPalette.TEXT);
		if (selected != null) {
			fit(graphics, selected.ip, 559, 188, 229, 0.78f, HgnPalette.TEXT_MUTED);
			fit(graphics, status(selected) + " / " + players(selected), 559, 211, 229, 0.73f, HgnPalette.TEXT_MUTED);
			fit(graphics, selected.version == null ? "Version unavailable" : selected.version.getString(),
				559, 234, 229, 0.75f, HgnPalette.TEXT_MUTED);
		}
		text(graphics, (page + 1) + " / " + Math.max(1, (visible.size() + 4) / 5), 260, 372, 0.8f, HgnPalette.TEXT_MUTED);
		fit(graphics, notice.isEmpty() ? "Double-click a server to join" : notice, 552, 373, 245, 0.73f, HgnPalette.TEXT_MUTED);
		super.render(graphics, mouseX, mouseY, partialTick);
	}

	private void renderCompact(GuiGraphics graphics, int mouseX, int mouseY) {
		HgnSurface.panel(graphics, HgnSavedServersLayout.header(width), false);
		HgnSurface.panel(graphics, HgnSavedServersLayout.content(width, height), false);
		List<ServerData> visible = filteredEntries();
		for (int index = page * 2; index < Math.min(visible.size(), page * 2 + 2); index++) {
			ServerData data = visible.get(index);
			HgnRect row = HgnSavedServersLayout.row(width, height, index % 2);
			HgnSurface.panel(graphics, row, data == selected || row.contains(mouseX, mouseY));
			compactFit(graphics, data.name, row.x() + 8, row.y() + 5, row.width() - 98,
				1.0f, HgnPalette.TEXT);
			compactFit(graphics, data.ip, row.x() + 8, row.y() + 17, row.width() - 98,
				0.9f, HgnPalette.TEXT_MUTED);
			compactFit(graphics, status(data), row.right() - 84, row.y() + 7, 77,
				0.85f, HgnPalette.CYAN);
		}
		int summaryY = HgnSavedServersLayout.row(width, height, 1).bottom() + 2;
		if (visible.isEmpty()) compactFit(graphics, !searchQuery.isBlank()
			? "No matching servers" : lan ? "Searching for LAN games..." : "No saved servers",
			16, 77, width - 32, 0.95f, HgnPalette.TEXT_MUTED);
		else compactFit(graphics, selected == null
			? "Select a server / " + (page + 1) + " of " + Math.max(1, (visible.size() + 1) / 2)
			: selected.name + " / " + players(selected), 16, summaryY, width - 32,
			0.9f, HgnPalette.TEXT_MUTED);
		if (!notice.isEmpty() && summaryY + 20 < HgnSavedServersLayout.join(width, height).y()) {
			compactFit(graphics, notice, 16, summaryY + 14, width - 32, 0.85f,
				HgnPalette.WARNING);
		}
	}

	private String status(ServerData data) {
		if (data.ping >= 0) return data.ping + " ms";
		return System.nanoTime() - queried.getOrDefault(data, refreshStarted) < 10_000_000_000L ? "Checking..." : "Unreachable";
	}

	private String players(ServerData data) {
		String host = net.minecraft.client.multiplayer.resolver.ServerAddress.parseString(data.ip).getHost();
		boolean official = online.horizongate.hgn.HgnOfficialServers.ALL.stream().anyMatch(server ->
			net.minecraft.client.multiplayer.resolver.ServerAddress.parseString(server.address()).getHost().equalsIgnoreCase(host));
		return HgnServerPopulation.fromMinecraftPing(official,
			data.players == null ? -1 : data.players.online(),
			data.players == null ? -1 : data.players.max());
	}

	private HgnButton button(int x, int y, int w, int h, String label, boolean primary, Runnable action) {
		var rect = frame.rect(x, y, w, h);
		return addRenderableWidget(HgnButton.dashboardCentered(rect.x(), rect.y(), rect.width(), rect.height(),
			Component.literal(label), primary, ignored -> action.run()).referenceScale(frame.scale() * 0.83f));
	}

	private void text(GuiGraphics graphics, String value, int x, int y, float size, int color) {
		HgnTypography.text(graphics, font, value, frame.x(x), frame.y(y), frame.scale() * size, color);
	}

	private void fit(GuiGraphics graphics, String value, int x, int y, int w, float size, int color) {
		text(graphics, HgnTypography.trim(font, value, (int) (w / size)), x, y, size, color);
	}

	private void compactFit(GuiGraphics graphics, String value, int x, int y, int width,
		float size, int color) {
		HgnTypography.text(graphics, font, HgnTypography.trim(font, value,
			Math.max(1, (int) (width / size))), x, y, size, color);
	}
}
