package online.horizongate.hgn.fabric;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.loader.api.FabricLoader;
import online.horizongate.hgn.HgnClient;
import online.horizongate.hgn.HgnPlatform;
import online.horizongate.hgn.net.HgnMessages;
import online.horizongate.hgn.net.HgnPayloads;

import java.nio.file.Path;

/**
 * Fabric entrypoint: installs the platform bridge and wires the HGN channels.
 * Start-up and join are driven from vanilla mixins shared with the other
 * loaders, so no Fabric lifecycle events are needed here.
 */
public final class HgnFabric implements ClientModInitializer, HgnPlatform {

	@Override
	public void onInitializeClient() {
		HgnPlatform.install(this);
		HgnClient.init();

		PayloadTypeRegistry.playS2C().register(HgnPayloads.Core.TYPE, HgnPayloads.Core.CODEC);
		PayloadTypeRegistry.playC2S().register(HgnPayloads.Core.TYPE, HgnPayloads.Core.CODEC);
		PayloadTypeRegistry.playS2C().register(HgnPayloads.Vink.TYPE, HgnPayloads.Vink.CODEC);

		ClientPlayNetworking.registerGlobalReceiver(HgnPayloads.Core.TYPE, (payload, context) ->
			context.client().execute(() -> HgnMessages.handleCore(payload.json())));
		ClientPlayNetworking.registerGlobalReceiver(HgnPayloads.Vink.TYPE, (payload, context) ->
			context.client().execute(() -> HgnMessages.handleVink(payload.json())));
	}

	@Override
	public Path configDir() {
		return FabricLoader.getInstance().getConfigDir();
	}

	@Override
	public boolean canSendCore() {
		return ClientPlayNetworking.canSend(HgnPayloads.Core.TYPE);
	}

	@Override
	public void sendCore(String json) {
		ClientPlayNetworking.send(new HgnPayloads.Core(json));
	}

	@Override
	public String loaderName() {
		return "fabric";
	}
}
